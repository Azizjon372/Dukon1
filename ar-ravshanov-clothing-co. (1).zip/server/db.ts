import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { Product, Category, Order, User, Review, DiscountCode, SiteSettings } from '../src/types.js';

interface DBData {
  products: Product[];
  categories: Category[];
  orders: Order[];
  users: User[];
  reviews: Review[];
  discounts: DiscountCode[];
  settings: SiteSettings;
}

const DB_FILE = path.join(process.cwd(), 'server_data.json');

const defaultSettings: SiteSettings = {
  companyName: 'AR RAVSHANOV CLOTHING CO.',
  logoText: 'AR',
  logoSubtext: 'RAVSHANOV CLOTHING CO.',
  phone: '+998 90 123 45 67',
  email: 'info@ravshanov.uz',
  address: "Toshkent sh., Amir Temur ko'chasi, 108-uy",
  telegram: '@azizravshanov',
  instagram: '@ravshanov_clothing',
  heroBadge: 'YANGI MAVSUM KOLLEKSIYASI 2026',
  heroHeadline: "BRANDINGIZNI BO'LISHING!",
  heroSubheadline: "ENG SO'NGGI ERKAKLAR VA AYOLLAR KOLLEKSIYALARINI KASHF ETING. PREMIUM SIFAT VA BEPUL YETKAZIB BERISH.",
  heroCtaText: 'XARID QILING',
  heroImage: 'https://images.unsplash.com/photo-1488161628813-04466f872be2?w=1200&q=80',
  freeShippingMinAmount: 500000,
  standardDeliveryFee: 25000,
  footerInfo: 'AR Ravshanov Clothing Co. — O\'zbekistondagi eng yetakchi premium kiyim va aksessuarlar brendi. Sifat va bejirim dizayn kafolati.'
};

const defaultCategories: Category[] = [
  { id: 'cat-1', name: 'Kiyimlar', slug: 'kiyimlar', image: 'https://images.unsplash.com/photo-1516826957135-700dedea698c?w=600&q=80', productCount: 6, description: 'Kurtkalar, xudilar, jinsilar va kostyumlar' },
  { id: 'cat-2', name: 'Aksessuarlar', slug: 'aksessuarlar', image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&q=80', productCount: 4, description: 'Soatlar, charm kamarlar va quyosh ko\'zoynaklari' },
  { id: 'cat-3', name: 'Oyoq kiyimlar', slug: 'oyoq-kiyimlar', image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600&q=80', productCount: 2, description: 'Krossovkalar va klassik tuflilar' },
  { id: 'cat-4', name: 'Yangi kelganlar', slug: 'yangi-kelganlar', image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=600&q=80', productCount: 8, description: 'So\'nggi trend va dizaynlar' }
];

const defaultProducts: Product[] = [
  {
    id: 'prod-1',
    name: 'PREMIUM HOODIE',
    description: 'Yumshoq va issiq saqlovchi 100% paxtali premium xudi. Har kunlik kiyish uchun juda qulay hamda bejirim ko\'rinishga ega.',
    price: 1350000,
    oldPrice: 1600000,
    discount: 15,
    category: 'Kiyimlar',
    brand: 'AR',
    sku: 'AR-HD-001',
    stock: 24,
    rating: 4.8,
    numReviews: 14,
    images: [
      'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&q=80',
      'https://images.unsplash.com/photo-1509967419530-da38b4704bc6?w=800&q=80'
    ],
    specifications: {
      'Material': '100% Paxta (Cotton)',
      'Rang': 'Klassik Kulrang',
      'O\'lchamlar': 'S, M, L, XL, XXL',
      'Ishlab chiqaruvchi': 'O\'zbekiston (AR Brand)'
    },
    isFeatured: true,
    isBestSeller: true,
    isPublished: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-2',
    name: 'DESIGNER JINSI',
    description: 'Zamonaviy qirqimli slim-fit jinsi shimlari. Yuqori elastiklik va mustahkam mato.',
    price: 980000,
    oldPrice: 1150000,
    discount: 15,
    category: 'Kiyimlar',
    brand: 'Stend',
    sku: 'AR-JN-002',
    stock: 18,
    rating: 4.7,
    numReviews: 9,
    images: [
      'https://images.unsplash.com/photo-1542272604-780c36856842?w=800&q=80'
    ],
    specifications: {
      'Material': 'Premium Denim 98%, Elastan 2%',
      'Style': 'Slim Fit',
      'Rang': 'To\'q Ko\'k'
    },
    isFeatured: true,
    isBestSeller: false,
    isPublished: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-3',
    name: 'LEATHER JACKET PREMIUM',
    description: '100% tabiiy charm erksaklar kurtkasi. Ipak astar va yapon zamog\'i bilan jihozlangan. Haqiqiy liderlar tanlovi.',
    price: 2100000,
    oldPrice: 2500000,
    discount: 16,
    category: 'Kiyimlar',
    brand: 'AR',
    sku: 'AR-LJ-003',
    stock: 12,
    rating: 4.9,
    numReviews: 22,
    images: [
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&q=80',
      'https://images.unsplash.com/photo-1520975954732-35dd22299614?w=800&q=80'
    ],
    specifications: {
      'Material': '100% Tabiiy Charm (Lambskin)',
      'Astar': 'Viskoza va Ipak',
      'Rang': 'Qora Klassik'
    },
    isFeatured: true,
    isBestSeller: true,
    isPublished: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-4',
    name: 'LEATHER JACKET CLASSIC',
    description: 'Klassik uslubdagi charmdan tayyorlangan kurtka. Shamol va sovuqdan ishonchli himoya.',
    price: 2300000,
    category: 'Kiyimlar',
    brand: 'Brvnd',
    sku: 'AR-LJ-004',
    stock: 8,
    rating: 4.6,
    numReviews: 7,
    images: [
      'https://images.unsplash.com/photo-1520975954732-35dd22299614?w=800&q=80'
    ],
    specifications: {
      'Material': 'Charm',
      'Astar': 'Flis',
      'Rang': 'To\'q Jigarrang'
    },
    isFeatured: true,
    isBestSeller: false,
    isPublished: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-5',
    name: 'AR LUXURY CHRONOGRAPH WATCH',
    description: 'Zanglamaydigan po\'lat korpus va safir oynali Shveytsariya mexanizmli lyuks erkaklar soati.',
    price: 3200000,
    oldPrice: 3800000,
    discount: 15,
    category: 'Aksessuarlar',
    brand: 'AR',
    sku: 'AR-WT-005',
    stock: 5,
    rating: 5.0,
    numReviews: 18,
    images: [
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=800&q=80'
    ],
    specifications: {
      'Mexanizm': 'Shveytsariya Kvarц',
      'Oyna': 'Sapphire Crystal',
      'Suv chidamliligi': '50 Metr (5 ATM)'
    },
    isFeatured: true,
    isBestSeller: true,
    isPublished: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-6',
    name: 'DESIGNER GOLD WATCH',
    description: 'Ko\'k siferblat va oltinrang korpusli eksklyuziv qo\'l soati.',
    price: 2850000,
    category: 'Aksessuarlar',
    brand: 'AR',
    sku: 'AR-WT-006',
    stock: 7,
    rating: 4.8,
    numReviews: 11,
    images: [
      'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&q=80'
    ],
    specifications: {
      'Kamar': 'Tabiiy Charm',
      'Rang': 'Oltin / Ko\'k'
    },
    isFeatured: true,
    isBestSeller: false,
    isPublished: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-7',
    name: 'CHARM KAMAR (LEATHER BELT)',
    description: 'Yuz foiz tabiiy charm va po\'lat to\'qali chidamli kamar.',
    price: 450000,
    category: 'Aksessuarlar',
    brand: 'AR',
    sku: 'AR-BL-007',
    stock: 30,
    rating: 4.7,
    numReviews: 15,
    images: [
      'https://images.unsplash.com/photo-1624222247344-550fb60583dc?w=800&q=80'
    ],
    specifications: {
      'Material': '100% Charm',
      'Rang': 'Qora / Jigarrang'
    },
    isFeatured: false,
    isBestSeller: true,
    isPublished: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-8',
    name: 'POLO SHIRT CLASSIC',
    description: 'Paxtali klassik yoqali futbolka. Barcha mavsum uchun mos.',
    price: 650000,
    oldPrice: 750000,
    discount: 13,
    category: 'Kiyimlar',
    brand: 'Polo',
    sku: 'AR-PL-008',
    stock: 20,
    rating: 4.5,
    numReviews: 8,
    images: [
      'https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?w=800&q=80'
    ],
    specifications: {
      'Material': 'Pike Paxta',
      'Rang': 'To\'q Ko\'k'
    },
    isFeatured: true,
    isBestSeller: false,
    isPublished: true,
    createdAt: new Date().toISOString()
  }
];

const defaultUsers: User[] = [
  {
    id: 'usr-admin',
    fullName: 'Aziz Ravshanov',
    email: 'admin@ravshanov.uz',
    phone: '+998 90 123 45 67',
    role: 'admin',
    isBlocked: false,
    city: 'Toshkent',
    address: 'Amir Temur ko\'chasi 108',
    createdAt: new Date().toISOString()
  },
  {
    id: 'usr-customer1',
    fullName: 'Jasur Shodmonov',
    email: 'jasur@gmail.com',
    phone: '+998 93 555 44 33',
    role: 'customer',
    isBlocked: false,
    city: 'Samarqand',
    address: 'Registon ko\'chasi 45',
    createdAt: new Date().toISOString()
  }
];

const defaultDiscounts: DiscountCode[] = [
  {
    id: 'disc-1',
    code: 'RAVSHANOV10',
    type: 'percentage',
    value: 10,
    minOrderAmount: 300000,
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    isActive: true,
    usageCount: 42
  },
  {
    id: 'disc-2',
    code: 'XUSHGELDI',
    type: 'fixed',
    value: 50000,
    minOrderAmount: 500000,
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    isActive: true,
    usageCount: 18
  }
];

const defaultOrders: Order[] = [
  {
    id: 'ORD-84920',
    userId: 'usr-customer1',
    customerName: 'Jasur Shodmonov',
    phone: '+998 93 555 44 33',
    city: 'Samarqand',
    address: 'Registon ko\'chasi 45',
    notes: 'Iltimos, soat 18:00 dan keyin yetkazib bering',
    items: [
      {
        id: 'item-1',
        productId: 'prod-1',
        name: 'PREMIUM HOODIE',
        image: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&q=80',
        price: 1350000,
        quantity: 1,
        selectedSize: 'L',
        selectedColor: 'Kulrang'
      }
    ],
    subtotal: 1350000,
    deliveryFee: 0,
    discountAmount: 135000,
    promoCode: 'RAVSHANOV10',
    total: 1215000,
    paymentMethod: 'Click',
    status: 'Yangi',
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 4).toISOString()
  },
  {
    id: 'ORD-84919',
    userId: 'usr-customer1',
    customerName: 'Sardor Rahimiv',
    phone: '+998 90 987 65 43',
    city: 'Toshkent',
    address: 'Chilonzor 12-daha 4-uy',
    items: [
      {
        id: 'item-2',
        productId: 'prod-3',
        name: 'LEATHER JACKET PREMIUM',
        image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&q=80',
        price: 2100000,
        quantity: 1,
        selectedSize: 'XL'
      }
    ],
    subtotal: 2100000,
    deliveryFee: 0,
    discountAmount: 0,
    total: 2100000,
    paymentMethod: 'Payme',
    status: 'Delivered' as any || 'Yetkazildi',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString()
  }
];

const defaultReviews: Review[] = [
  {
    id: 'rev-1',
    productId: 'prod-1',
    productName: 'PREMIUM HOODIE',
    userName: 'Otabek M.',
    rating: 5,
    comment: 'Materiali juda sifatli va paxtasi yumshoq! O\'zbekistonda shunday brend borligidan xursandman. Aziz Ravshanov jamoasiga rahmat!',
    isApproved: true,
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString()
  },
  {
    id: 'rev-2',
    productId: 'prod-3',
    productName: 'LEATHER JACKET PREMIUM',
    userName: 'Dilshod R.',
    rating: 5,
    comment: 'Haqiqiy charm kurtka. Kiyganda juda bejirim turadi. Bepul va tez yetkazib berishdi.',
    isApproved: true,
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString()
  }
];

export function getDB(): DBData {
  if (!fs.existsSync(DB_FILE)) {
    const initialData: DBData = {
      products: defaultProducts,
      categories: defaultCategories,
      orders: defaultOrders,
      users: defaultUsers,
      reviews: defaultReviews,
      discounts: defaultDiscounts,
      settings: defaultSettings
    };
    saveDB(initialData);
    return initialData;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    return {
      products: parsed.products || defaultProducts,
      categories: parsed.categories || defaultCategories,
      orders: parsed.orders || defaultOrders,
      users: parsed.users || defaultUsers,
      reviews: parsed.reviews || defaultReviews,
      discounts: parsed.discounts || defaultDiscounts,
      settings: parsed.settings || defaultSettings
    };
  } catch (err) {
    console.error('Error reading DB, re-initializing...', err);
    const initialData: DBData = {
      products: defaultProducts,
      categories: defaultCategories,
      orders: defaultOrders,
      users: defaultUsers,
      reviews: defaultReviews,
      discounts: defaultDiscounts,
      settings: defaultSettings
    };
    saveDB(initialData);
    return initialData;
  }
}

export function saveDB(data: DBData): void {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
}
