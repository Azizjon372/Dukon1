import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { createServer as createViteServer } from 'vite';
import { getDB, saveDB } from './server/db.js';
import { User, Product, Category, Order, Review, DiscountCode, SiteSettings } from './src/types.js';

const JWT_SECRET = process.env.JWT_SECRET || 'ravshanov_clothing_super_secret_jwt_key_2026';
const PORT = 3000;

interface AuthRequest extends Request {
  user?: User;
}

const app = express();

// Set high body limit for base64 gallery uploads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Localhost uploads static folder
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
app.use('/uploads', express.static(uploadsDir));

// Endpoint to upload base64 image and save to local disk file
app.post('/api/upload', (req: Request, res: Response) => {
  try {
    const { imageBase64 } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ message: 'Rasm yuborilmadi' });
    }

    if (!imageBase64.startsWith('data:image')) {
      return res.json({ url: imageBase64 });
    }

    const matches = imageBase64.match(/^data:image\/([A-Za-z-+\/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      return res.json({ url: imageBase64 });
    }

    const rawExt = matches[1];
    const ext = rawExt === 'jpeg' ? 'jpg' : rawExt.includes('svg') ? 'svg' : rawExt.split('+')[0];
    const buffer = Buffer.from(matches[2], 'base64');
    const fileName = `img_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${ext}`;
    const filePath = path.join(uploadsDir, fileName);

    fs.writeFileSync(filePath, buffer);
    const fileUrl = `/uploads/${fileName}`;

    return res.json({ url: fileUrl });
  } catch (err: any) {
    console.error('Upload Error:', err);
    return res.status(500).json({ message: 'Rasm saqlashda xatolik yuz berdi' });
  }
});

// Middleware to authenticate JWT
const authenticateToken = (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Token talab qilinadi' });
  }

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ message: 'Noto\'g\'ri yoki muddati o\'tgan token' });
    }
    req.user = decoded as User;
    next();
  });
};

// Middleware for Admin-only routes
const requireAdmin = (req: AuthRequest, res: Response, next: NextFunction) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Faqat admin uchun ruxsat berilgan' });
  }
  next();
};

// =================== AUTH ENDPOINTS ===================

// Register User
app.post('/api/auth/register', async (req: Request, res: Response) => {
  try {
    const { fullName, email, password, phone, city, address } = req.body;
    if (!fullName || !email || !password) {
      return res.status(400).json({ message: 'Iltimos, barcha majburiy maydonlarni to\'ldiring' });
    }

    const db = getDB();
    const existing = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      let isMatch = false;
      if ((existing as any).passwordHash) {
        isMatch = await bcrypt.compare(password, (existing as any).passwordHash);
      } else {
        isMatch = (password === 'admin123' && existing.role === 'admin') || password === 'user123';
      }

      if (isMatch) {
        const token = jwt.sign(
          { id: existing.id, fullName: existing.fullName, email: existing.email, role: existing.role },
          JWT_SECRET,
          { expiresIn: '7d' }
        );
        const { passwordHash, ...userClean } = existing as any;
        return res.json({ token, user: userClean, message: 'Hisobingizga muvaffaqiyatli kirildi' });
      } else {
        return res.status(400).json({
          message: 'Ushbu email allaqachon ro\'yxatdan o\'tgan. Iltimos, parolingizni to\'g\'ri kiriting yoki "Tizimga kirish" sahifasidan kiring.'
        });
      }
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser: User & { passwordHash?: string } = {
      id: `usr-${Date.now()}`,
      fullName,
      email,
      phone: phone || '',
      role: 'customer',
      isBlocked: false,
      city: city || 'Toshkent',
      address: address || '',
      createdAt: new Date().toISOString()
    };

    // Store user with hashed password in DB
    (newUser as any).passwordHash = hashedPassword;
    db.users.push(newUser as User);
    saveDB(db);

    const token = jwt.sign(
      { id: newUser.id, fullName: newUser.fullName, email: newUser.email, role: newUser.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash, ...userClean } = newUser as any;
    res.status(201).json({ token, user: userClean });
  } catch (err: any) {
    res.status(500).json({ message: 'Tizimda xatolik: ' + err.message });
  }
});

// Login User & Admin
app.post('/api/auth/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: 'Email va parolni kiriting' });
    }

    const db = getDB();
    const user = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase()) as any;

    if (!user) {
      // Default Admin bypass fallback
      if (email === 'admin@ravshanov.uz' && password === 'admin123') {
        const adminUser: User = {
          id: 'usr-admin',
          fullName: 'Aziz Ravshanov',
          email: 'admin@ravshanov.uz',
          phone: '+998 90 123 45 67',
          role: 'admin',
          isBlocked: false,
          createdAt: new Date().toISOString()
        };
        const token = jwt.sign(
          { id: adminUser.id, fullName: adminUser.fullName, email: adminUser.email, role: adminUser.role },
          JWT_SECRET,
          { expiresIn: '7d' }
        );
        return res.json({ token, user: adminUser });
      }
      return res.status(400).json({ message: 'Noto\'g\'ri email yoki parol' });
    }

    if (user.isBlocked) {
      return res.status(403).json({ message: 'Hisobingiz bloklangan. Iltimos, ma\'muriyat bilan bog\'laning.' });
    }

    let isMatch = false;
    if (user.passwordHash) {
      isMatch = await bcrypt.compare(password, user.passwordHash);
    } else {
      // Default seeded fallback
      isMatch = (password === 'admin123' && user.role === 'admin') || password === 'user123';
    }

    if (!isMatch) {
      return res.status(400).json({ message: 'Noto\'g\'ri email yoki parol' });
    }

    const token = jwt.sign(
      { id: user.id, fullName: user.fullName, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash, ...userClean } = user;
    res.json({ token, user: userClean });
  } catch (err: any) {
    res.status(500).json({ message: 'Tizimda xatolik: ' + err.message });
  }
});

// Current User Profile
app.get('/api/auth/me', authenticateToken, (req: AuthRequest, res: Response) => {
  const db = getDB();
  const user = db.users.find((u) => u.id === req.user?.id);
  if (!user) {
    return res.status(404).json({ message: 'Foydalanuvchi topilmadi' });
  }
  const { passwordHash, ...userClean } = user as any;
  res.json(userClean);
});

// Update Profile
app.put('/api/auth/profile', authenticateToken, (req: AuthRequest, res: Response) => {
  const db = getDB();
  const index = db.users.findIndex((u) => u.id === req.user?.id);
  if (index === -1) {
    return res.status(404).json({ message: 'Foydalanuvchi topilmadi' });
  }

  const { fullName, phone, city, address } = req.body;
  db.users[index] = {
    ...db.users[index],
    fullName: fullName || db.users[index].fullName,
    phone: phone || db.users[index].phone,
    city: city || db.users[index].city,
    address: address || db.users[index].address
  };

  saveDB(db);
  const { passwordHash, ...userClean } = db.users[index] as any;
  res.json(userClean);
});

// =================== PRODUCTS ENDPOINTS ===================

// Get all products with filter / search / sort / pagination
app.get('/api/products', (req: Request, res: Response) => {
  const db = getDB();
  let products = [...db.products];

  const search = (req.query.search as string || '').toLowerCase().trim();
  const category = req.query.category as string;
  const brand = req.query.brand as string;
  const minPrice = parseFloat(req.query.minPrice as string);
  const maxPrice = parseFloat(req.query.maxPrice as string);
  const isFeatured = req.query.isFeatured === 'true';
  const isBestSeller = req.query.isBestSeller === 'true';
  const sortBy = req.query.sortBy as string || 'newest'; // 'price_asc', 'price_desc', 'rating', 'newest'
  const page = parseInt(req.query.page as string || '1');
  const limit = parseInt(req.query.limit as string || '20');

  // Exclude unpublished for non-admin requests if needed
  if (req.query.publishedOnly !== 'false') {
    products = products.filter((p) => p.isPublished !== false);
  }

  if (search) {
    products = products.filter(
      (p) =>
        p.name.toLowerCase().includes(search) ||
        p.description.toLowerCase().includes(search) ||
        p.brand.toLowerCase().includes(search) ||
        p.category.toLowerCase().includes(search) ||
        p.sku.toLowerCase().includes(search)
    );
  }

  if (category && category !== 'barchasi') {
    products = products.filter((p) => p.category.toLowerCase() === category.toLowerCase());
  }

  if (brand) {
    products = products.filter((p) => p.brand.toLowerCase() === brand.toLowerCase());
  }

  if (!isNaN(minPrice)) {
    products = products.filter((p) => p.price >= minPrice);
  }

  if (!isNaN(maxPrice)) {
    products = products.filter((p) => p.price <= maxPrice);
  }

  if (isFeatured) {
    products = products.filter((p) => p.isFeatured);
  }

  if (isBestSeller) {
    products = products.filter((p) => p.isBestSeller);
  }

  // Sorting
  if (sortBy === 'price_asc') {
    products.sort((a, b) => a.price - b.price);
  } else if (sortBy === 'price_desc') {
    products.sort((a, b) => b.price - a.price);
  } else if (sortBy === 'rating') {
    products.sort((a, b) => b.rating - a.rating);
  } else {
    // Newest first
    products.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  const total = products.length;
  const startIndex = (page - 1) * limit;
  const paginatedProducts = products.slice(startIndex, startIndex + limit);

  res.json({
    products: paginatedProducts,
    total,
    page,
    totalPages: Math.ceil(total / limit)
  });
});

// Single product details
app.get('/api/products/:id', (req: Request, res: Response) => {
  const db = getDB();
  const product = db.products.find((p) => p.id === req.params.id);
  if (!product) {
    return res.status(404).json({ message: 'Mahsulot topilmadi' });
  }
  const related = db.products.filter(
    (p) => p.id !== product.id && p.category === product.category
  ).slice(0, 4);

  res.json({ product, related });
});

// Admin Add Product
app.post('/api/products', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  const {
    name,
    description,
    price,
    oldPrice,
    discount,
    category,
    brand,
    sku,
    stock,
    images,
    specifications,
    isFeatured,
    isBestSeller,
    isPublished
  } = req.body;

  if (!name || !price || !category) {
    return res.status(400).json({ message: 'Nomi, narxi va kategoriyasi talab qilinadi' });
  }

  const newProduct: Product = {
    id: `prod-${Date.now()}`,
    name,
    description: description || '',
    price: Number(price),
    oldPrice: oldPrice ? Number(oldPrice) : undefined,
    discount: discount ? Number(discount) : undefined,
    category,
    brand: brand || 'AR',
    sku: sku || `SKU-${Date.now().toString().slice(-6)}`,
    stock: stock ? Number(stock) : 10,
    rating: 5.0,
    numReviews: 0,
    images: Array.isArray(images) && images.length > 0 ? images : ['https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&q=80'],
    specifications: specifications || {},
    isFeatured: Boolean(isFeatured),
    isBestSeller: Boolean(isBestSeller),
    isPublished: isPublished !== false,
    createdAt: new Date().toISOString()
  };

  db.products.unshift(newProduct);
  saveDB(db);
  res.status(201).json(newProduct);
});

// Admin Edit Product
app.put('/api/products/:id', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  const index = db.products.findIndex((p) => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ message: 'Mahsulot topilmadi' });
  }

  const existing = db.products[index];
  const updated: Product = {
    ...existing,
    ...req.body,
    price: req.body.price ? Number(req.body.price) : existing.price,
    oldPrice: req.body.oldPrice ? Number(req.body.oldPrice) : existing.oldPrice,
    discount: req.body.discount ? Number(req.body.discount) : existing.discount,
    stock: req.body.stock !== undefined ? Number(req.body.stock) : existing.stock
  };

  db.products[index] = updated;
  saveDB(db);
  res.json(updated);
});

// Admin Delete Product
app.delete('/api/products/:id', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  db.products = db.products.filter((p) => p.id !== req.params.id);
  saveDB(db);
  res.json({ message: 'Mahsulot muvaffaqiyatli o\'chirildi' });
});

// =================== CATEGORIES ENDPOINTS ===================

app.get('/api/categories', (req: Request, res: Response) => {
  const db = getDB();
  // Update count
  const categories = db.categories.map((cat) => {
    const count = db.products.filter((p) => p.category.toLowerCase() === cat.name.toLowerCase()).length;
    return { ...cat, productCount: count };
  });
  res.json(categories);
});

app.post('/api/categories', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  const { name, image, description } = req.body;
  if (!name) {
    return res.status(400).json({ message: 'Kategoriya nomi kiritilishi shart' });
  }

  const newCat: Category = {
    id: `cat-${Date.now()}`,
    name,
    slug: name.toLowerCase().replace(/\s+/g, '-'),
    image: image || 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&q=80',
    description: description || '',
    productCount: 0
  };

  db.categories.push(newCat);
  saveDB(db);
  res.status(201).json(newCat);
});

app.put('/api/categories/:id', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  const index = db.categories.findIndex((c) => c.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ message: 'Kategoriya topilmadi' });
  }
  db.categories[index] = { ...db.categories[index], ...req.body };
  saveDB(db);
  res.json(db.categories[index]);
});

app.delete('/api/categories/:id', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  db.categories = db.categories.filter((c) => c.id !== req.params.id);
  saveDB(db);
  res.json({ message: 'Kategoriya o\'chirildi' });
});

// =================== ORDERS ENDPOINTS ===================

// Create Order
app.post('/api/orders', (req: Request, res: Response) => {
  const db = getDB();
  const { customerName, phone, city, address, notes, items, subtotal, deliveryFee, discountAmount, promoCode, total, paymentMethod, userId } = req.body;

  if (!customerName || !phone || !city || !address || !items || items.length === 0) {
    return res.status(400).json({ message: 'Iltimos, yetkazib berish ma\'lumotlarini va mahsulotlarni kiriting' });
  }

  const orderId = `ORD-${Math.floor(10000 + Math.random() * 90000)}`;
  const newOrder: Order = {
    id: orderId,
    userId: userId || undefined,
    customerName,
    phone,
    city,
    address,
    notes: notes || '',
    items,
    subtotal: Number(subtotal),
    deliveryFee: Number(deliveryFee || 0),
    discountAmount: Number(discountAmount || 0),
    promoCode: promoCode || undefined,
    total: Number(total),
    paymentMethod: paymentMethod || 'Naqd',
    status: 'Yangi',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  db.orders.unshift(newOrder);

  // Reduce product stock
  items.forEach((item: any) => {
    const prod = db.products.find((p) => p.id === item.productId);
    if (prod && prod.stock >= item.quantity) {
      prod.stock -= item.quantity;
    }
  });

  saveDB(db);
  res.status(201).json(newOrder);
});

// Get User Orders
app.get('/api/orders/my-orders', authenticateToken, (req: AuthRequest, res: Response) => {
  const db = getDB();
  const userOrders = db.orders.filter((o) => o.userId === req.user?.id || o.phone === req.user?.phone);
  res.json(userOrders);
});

// Admin Get Orders
app.get('/api/orders', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  res.json(db.orders);
});

// Admin Update Order Status
app.patch('/api/orders/:id/status', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) {
    return res.status(404).json({ message: 'Buyurtma topilmadi' });
  }

  const { status } = req.body;
  if (!status) {
    return res.status(400).json({ message: 'Status kiritilmadi' });
  }

  order.status = status;
  order.updatedAt = new Date().toISOString();
  saveDB(db);
  res.json(order);
});

// =================== CUSTOMERS ENDPOINTS ===================

app.get('/api/customers', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  const customers = db.users.map((u) => {
    const userOrders = db.orders.filter((o) => o.userId === u.id || o.phone === u.phone);
    const totalSpent = userOrders.reduce((acc, curr) => acc + curr.total, 0);
    const { passwordHash, ...clean } = u as any;
    return {
      ...clean,
      orderCount: userOrders.length,
      totalSpent
    };
  });
  res.json(customers);
});

app.patch('/api/customers/:id/block', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  const user = db.users.find((u) => u.id === req.params.id);
  if (!user) {
    return res.status(404).json({ message: 'Foydalanuvchi topilmadi' });
  }

  user.isBlocked = !user.isBlocked;
  saveDB(db);
  res.json({ message: user.isBlocked ? 'Foydalanuvchi bloklandi' : 'Foydalanuvchi blokdan chiqarildi', isBlocked: user.isBlocked });
});

// =================== REVIEWS ENDPOINTS ===================

app.get('/api/reviews', (req: Request, res: Response) => {
  const db = getDB();
  const productId = req.query.productId as string;
  let reviews = [...db.reviews];

  if (productId) {
    reviews = reviews.filter((r) => r.productId === productId && r.isApproved);
  } else if (req.query.all !== 'true') {
    reviews = reviews.filter((r) => r.isApproved);
  }

  res.json(reviews);
});

app.post('/api/reviews', (req: Request, res: Response) => {
  const db = getDB();
  const { productId, userName, rating, comment } = req.body;
  if (!productId || !userName || !rating || !comment) {
    return res.status(400).json({ message: 'Barcha maydonlarni to\'ldiring' });
  }

  const prod = db.products.find((p) => p.id === productId);

  const newReview: Review = {
    id: `rev-${Date.now()}`,
    productId,
    productName: prod ? prod.name : 'Noma\'lum',
    userName,
    rating: Number(rating),
    comment,
    isApproved: true, // Auto approve or pending
    createdAt: new Date().toISOString()
  };

  db.reviews.unshift(newReview);

  // Recalculate rating
  if (prod) {
    const prodReviews = db.reviews.filter((r) => r.productId === productId);
    const avg = prodReviews.reduce((sum, r) => sum + r.rating, 0) / prodReviews.length;
    prod.rating = Number(avg.toFixed(1));
    prod.numReviews = prodReviews.length;
  }

  saveDB(db);
  res.status(201).json(newReview);
});

app.patch('/api/reviews/:id/approve', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  const rev = db.reviews.find((r) => r.id === req.params.id);
  if (!rev) {
    return res.status(404).json({ message: 'Sharh topilmadi' });
  }
  rev.isApproved = !rev.isApproved;
  saveDB(db);
  res.json(rev);
});

app.delete('/api/reviews/:id', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  db.reviews = db.reviews.filter((r) => r.id !== req.params.id);
  saveDB(db);
  res.json({ message: 'Sharh o\'chirildi' });
});

// =================== DISCOUNTS & PROMO CODES ===================

app.post('/api/discounts/validate', (req: Request, res: Response) => {
  const { code, amount } = req.body;
  if (!code) {
    return res.status(400).json({ message: 'Promo kodni kiriting' });
  }

  const db = getDB();
  const promo = db.discounts.find((d) => d.code.toUpperCase() === code.toUpperCase() && d.isActive);

  if (!promo) {
    return res.status(404).json({ message: 'Promokod mavjud emas yoki faol emas' });
  }

  if (promo.minOrderAmount && amount < promo.minOrderAmount) {
    return res.status(400).json({ message: `Ushbu promokod faqat kamida ${promo.minOrderAmount.toLocaleString()} UZS xaridlar uchun amal qiladi` });
  }

  let discountAmount = 0;
  if (promo.type === 'percentage') {
    discountAmount = Math.round((amount * promo.value) / 100);
  } else {
    discountAmount = promo.value;
  }

  res.json({
    code: promo.code,
    discountAmount,
    type: promo.type,
    value: promo.value
  });
});

app.get('/api/discounts', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  res.json(db.discounts);
});

app.post('/api/discounts', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  const { code, type, value, minOrderAmount, startDate, endDate } = req.body;
  if (!code || !type || !value) {
    return res.status(400).json({ message: 'Promokod nomi va qiymatini kiriting' });
  }

  const newDiscount: DiscountCode = {
    id: `disc-${Date.now()}`,
    code: code.toUpperCase(),
    type,
    value: Number(value),
    minOrderAmount: minOrderAmount ? Number(minOrderAmount) : undefined,
    startDate: startDate || new Date().toISOString().split('T')[0],
    endDate: endDate || '2026-12-31',
    isActive: true,
    usageCount: 0
  };

  db.discounts.push(newDiscount);
  saveDB(db);
  res.status(201).json(newDiscount);
});

app.delete('/api/discounts/:id', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  db.discounts = db.discounts.filter((d) => d.id !== req.params.id);
  saveDB(db);
  res.json({ message: 'Promokod o\'chirildi' });
});

// =================== SITE SETTINGS ENDPOINTS ===================

app.get('/api/settings', (req: Request, res: Response) => {
  const db = getDB();
  res.json(db.settings);
});

app.put('/api/settings', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();
  db.settings = { ...db.settings, ...req.body };
  saveDB(db);
  res.json(db.settings);
});

// =================== DASHBOARD STATS ENDPOINTS ===================

app.get('/api/stats', authenticateToken, requireAdmin, (req: Request, res: Response) => {
  const db = getDB();

  const totalRevenue = db.orders.reduce((acc, curr) => acc + curr.total, 0);
  const totalOrders = db.orders.length;
  const totalCustomers = db.users.filter((u) => u.role === 'customer').length;
  const totalProducts = db.products.length;

  const salesData = [
    { name: 'Yanvar', revenue: 12500000, orders: 15 },
    { name: 'Fevral', revenue: 18400000, orders: 22 },
    { name: 'Mart', revenue: 24100000, orders: 31 },
    { name: 'Aprel', revenue: 29800000, orders: 38 },
    { name: 'May', revenue: 35200000, orders: 42 },
    { name: 'Iyun', revenue: 41000000, orders: 49 },
    { name: 'Iyul', revenue: 48500000, orders: 56 },
    { name: 'Avgust', revenue: totalRevenue > 0 ? totalRevenue : 52000000, orders: totalOrders }
  ];

  const weeklyData = [
    { day: 'Dush', sales: 4200000 },
    { day: 'Sesh', sales: 6800000 },
    { day: 'Chor', sales: 5100000 },
    { day: 'Pay', sales: 8900000 },
    { day: 'Jum', sales: 11200000 },
    { day: 'Shan', sales: 14500000 },
    { day: 'Yak', sales: 9800000 }
  ];

  const recentOrders = db.orders.slice(0, 5);
  const bestSellers = db.products.filter((p) => p.isBestSeller).slice(0, 5);
  const lowStockProducts = db.products.filter((p) => p.stock <= 10);

  res.json({
    totalRevenue,
    totalOrders,
    totalCustomers,
    totalProducts,
    salesData,
    weeklyData,
    recentOrders,
    bestSellers,
    lowStockProducts
  });
});

// =================== VITE SERVING & PRODUCTION SETUP ===================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
