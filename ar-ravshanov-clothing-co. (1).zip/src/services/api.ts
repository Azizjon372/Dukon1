import { Product, Category, Order, User, Review, DiscountCode, SiteSettings, DashboardStats } from '../types';

const API_BASE = '/api';

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('ar_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function fetchProducts(params: Record<string, any> = {}): Promise<{ products: Product[]; total: number; page: number; totalPages: number }> {
  const query = new URLSearchParams(params).toString();
  const res = await fetch(`${API_BASE}/products?${query}`);
  if (!res.ok) throw new Error('Mahsulotlarni yuklashda xatolik');
  return res.json();
}

export async function fetchProductById(id: string): Promise<{ product: Product; related: Product[] }> {
  const res = await fetch(`${API_BASE}/products/${id}`);
  if (!res.ok) throw new Error('Mahsulot topilmadi');
  return res.json();
}

export async function createProduct(data: Partial<Product>): Promise<Product> {
  const res = await fetch(`${API_BASE}/products`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
    body: JSON.stringify(data)
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || 'Mahsulot yaratishda xatolik');
  }
  return res.json();
}

export async function updateProduct(id: string, data: Partial<Product>): Promise<Product> {
  const res = await fetch(`${API_BASE}/products/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
    body: JSON.stringify(data)
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || 'Mahsulotni tahrirlashda xatolik');
  }
  return res.json();
}

export async function deleteProduct(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/products/${id}`, {
    method: 'DELETE',
    headers: getAuthHeader()
  });
  if (!res.ok) throw new Error('Mahsulotni o\'chirishda xatolik');
}

export async function fetchCategories(): Promise<Category[]> {
  const res = await fetch(`${API_BASE}/categories`);
  if (!res.ok) throw new Error('Kategoriyalarni yuklashda xatolik');
  return res.json();
}

export async function createCategory(data: { name: string; image?: string; description?: string }): Promise<Category> {
  const res = await fetch(`${API_BASE}/categories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Kategoriya qo\'shishda xatolik');
  return res.json();
}

export async function updateCategory(id: string, data: Partial<Category>): Promise<Category> {
  const res = await fetch(`${API_BASE}/categories/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Kategoriyani tahrirlashda xatolik');
  return res.json();
}

export async function deleteCategory(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/categories/${id}`, {
    method: 'DELETE',
    headers: getAuthHeader()
  });
  if (!res.ok) throw new Error('Kategoriyani o\'chirishda xatolik');
}

export async function createOrder(data: any): Promise<Order> {
  const res = await fetch(`${API_BASE}/orders`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || 'Buyurtma rasmiylashtirishda xatolik');
  }
  return res.json();
}

export async function fetchMyOrders(): Promise<Order[]> {
  const res = await fetch(`${API_BASE}/orders/my-orders`, {
    headers: getAuthHeader()
  });
  if (!res.ok) throw new Error('Buyurtmalarni yuklashda xatolik');
  return res.json();
}

export async function fetchAdminOrders(): Promise<Order[]> {
  const res = await fetch(`${API_BASE}/orders`, {
    headers: getAuthHeader()
  });
  if (!res.ok) throw new Error('Buyurtmalarni yuklashda xatolik');
  return res.json();
}

export async function updateOrderStatus(id: string, status: string): Promise<Order> {
  const res = await fetch(`${API_BASE}/orders/${id}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
    body: JSON.stringify({ status })
  });
  if (!res.ok) throw new Error('Buyurtma statusini o\'zgartirishda xatolik');
  return res.json();
}

export async function fetchCustomers(): Promise<any[]> {
  const res = await fetch(`${API_BASE}/customers`, {
    headers: getAuthHeader()
  });
  if (!res.ok) throw new Error('Mijozlarni yuklashda xatolik');
  return res.json();
}

export async function toggleCustomerBlock(id: string): Promise<any> {
  const res = await fetch(`${API_BASE}/customers/${id}/block`, {
    method: 'PATCH',
    headers: getAuthHeader()
  });
  if (!res.ok) throw new Error('Mijoz statusini o\'zgartirishda xatolik');
  return res.json();
}

export async function fetchReviews(productId?: string): Promise<Review[]> {
  const url = productId ? `${API_BASE}/reviews?productId=${productId}` : `${API_BASE}/reviews?all=true`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Sharhlarni yuklashda xatolik');
  return res.json();
}

export async function createReview(data: { productId: string; userName: string; rating: number; comment: string }): Promise<Review> {
  const res = await fetch(`${API_BASE}/reviews`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Sharh qoldirishda xatolik');
  return res.json();
}

export async function approveReview(id: string): Promise<Review> {
  const res = await fetch(`${API_BASE}/reviews/${id}/approve`, {
    method: 'PATCH',
    headers: getAuthHeader()
  });
  if (!res.ok) throw new Error('Sharhni tasdiqlashda xatolik');
  return res.json();
}

export async function deleteReview(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/reviews/${id}`, {
    method: 'DELETE',
    headers: getAuthHeader()
  });
  if (!res.ok) throw new Error('Sharhni o\'chirishda xatolik');
}

export async function validatePromoCode(code: string, amount: number): Promise<any> {
  const res = await fetch(`${API_BASE}/discounts/validate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code, amount })
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || 'Noto\'g\'ri promokod');
  }
  return res.json();
}

export async function fetchDiscounts(): Promise<DiscountCode[]> {
  const res = await fetch(`${API_BASE}/discounts`, {
    headers: getAuthHeader()
  });
  if (!res.ok) throw new Error('Promokodlarni yuklashda xatolik');
  return res.json();
}

export async function createDiscount(data: any): Promise<DiscountCode> {
  const res = await fetch(`${API_BASE}/discounts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Promokod yaratishda xatolik');
  return res.json();
}

export async function deleteDiscount(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/discounts/${id}`, {
    method: 'DELETE',
    headers: getAuthHeader()
  });
  if (!res.ok) throw new Error('Promokodni o\'chirishda xatolik');
}

export async function fetchSiteSettings(): Promise<SiteSettings> {
  const res = await fetch(`${API_BASE}/settings`);
  if (!res.ok) throw new Error('Sozlamalarni yuklashda xatolik');
  return res.json();
}

export async function updateSiteSettings(data: Partial<SiteSettings>): Promise<SiteSettings> {
  const res = await fetch(`${API_BASE}/settings`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Sozlamalarni saqlashda xatolik');
  return res.json();
}

export async function fetchDashboardStats(): Promise<DashboardStats> {
  const res = await fetch(`${API_BASE}/stats`, {
    headers: getAuthHeader()
  });
  if (!res.ok) throw new Error('Statistikani yuklashda xatolik');
  return res.json();
}

export async function uploadImage(imageBase64: string): Promise<string> {
  if (!imageBase64 || !imageBase64.startsWith('data:image')) {
    return imageBase64;
  }
  try {
    const res = await fetch(`${API_BASE}/upload`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify({ imageBase64 })
    });
    if (!res.ok) return imageBase64;
    const data = await res.json();
    return data.url || imageBase64;
  } catch (err) {
    console.error('Upload Error:', err);
    return imageBase64;
  }
}
