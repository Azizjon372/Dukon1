import React, { useState } from 'react';
import { ShieldCheck, Truck, CreditCard, ArrowLeft, CheckCircle2, AlertCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { createOrder } from '../services/api';
import { Order } from '../types';
import { formatUzPhone } from '../lib/utils';

interface CheckoutPageProps {
  onBackToShop: () => void;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({ onBackToShop, onOrderSuccess }) => {
  const { cart, subtotal, deliveryFee, discountAmount, total, appliedPromo, clearCart } = useCart();
  const { user } = useAuth();

  const [customerName, setCustomerName] = useState(user?.fullName || '');
  const [phone, setPhone] = useState(user?.phone ? formatUzPhone(user.phone) : '+998 ');
  const [city, setCity] = useState(user?.city || 'Toshkent');
  const [address, setAddress] = useState(user?.address || '');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Click' | 'Payme' | 'Uzcard/Humo' | 'Naqd'>('Click');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [attempted, setAttempted] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  const formatPrice = (price: number) => price.toLocaleString('uz-UZ') + ' UZS';

  const handlePhoneChange = (val: string) => {
    setPhone(formatUzPhone(val));
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setAttempted(true);
    setError('');

    if (!customerName.trim() || !phone.trim() || phone.trim() === '+998' || !address.trim()) {
      setError('To\'ldirish shart! Iltimos, barcha qizil bilan belgilangan maydonlarni to\'liq to\'ldiring.');
      return;
    }

    if (cart.length === 0) {
      setError('Savatchangizda mahsulot yo\'q');
      return;
    }

    setIsSubmitting(true);

    try {
      const orderData = {
        userId: user?.id,
        customerName: customerName.trim(),
        phone: phone.trim(),
        city,
        address: address.trim(),
        notes: notes.trim(),
        items: cart,
        subtotal,
        deliveryFee,
        discountAmount,
        promoCode: appliedPromo?.code,
        total,
        paymentMethod
      };

      const newOrder = await createOrder(orderData);
      clearCart();
      setCompletedOrder(newOrder);
      onOrderSuccess(newOrder);
    } catch (err: any) {
      setError(err.message || 'Buyurtmani rasmiylashtirishda xatolik yuz berdi');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (completedOrder) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-6 animate-in fade-in">
        <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-md">
          <CheckCircle2 className="w-12 h-12" />
        </div>

        <div className="space-y-2">
          <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full uppercase">
            BUYURTMA QABUL QILINDI!
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 uppercase font-sans">
            Rahmat, {completedOrder.customerName}!
          </h1>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Buyurtmangiz muvaffaqiyatli rasmiylashtirildi. Tez orada operatorimiz siz bilan bog'lanadi.
          </p>
        </div>

        {/* Tracking ID card */}
        <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-xl space-y-3 text-left">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <span className="text-xs text-slate-400">BUYURTMA ID (TRACKING):</span>
            <span className="font-mono text-amber-400 font-extrabold text-base">
              {completedOrder.id}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <p className="text-slate-400">Jami summasi:</p>
              <p className="font-bold text-white">{formatPrice(completedOrder.total)}</p>
            </div>
            <div>
              <p className="text-slate-400">To'lov usuli:</p>
              <p className="font-bold text-amber-400">{completedOrder.paymentMethod}</p>
            </div>
            <div>
              <p className="text-slate-400">Yetkazish manzili:</p>
              <p className="font-bold text-white truncate">{completedOrder.city}, {completedOrder.address}</p>
            </div>
            <div>
              <p className="text-slate-400">Holati:</p>
              <p className="font-bold text-emerald-400">{completedOrder.status}</p>
            </div>
          </div>
        </div>

        <div className="pt-4 flex justify-center space-x-4">
          <button
            onClick={onBackToShop}
            className="bg-slate-900 text-amber-400 font-black px-6 py-3 rounded-xl text-xs uppercase tracking-wider hover:bg-slate-800 transition-all"
          >
            Bosh sahifaga qaytish
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 space-y-8">
      {/* Back Button */}
      <button
        onClick={onBackToShop}
        className="flex items-center space-x-2 text-xs font-bold text-slate-600 hover:text-slate-900"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Xaridni davom ettirish</span>
      </button>

      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 uppercase font-sans">
          BUYURTMANI RASMIYLASHTIRISH (CHECKOUT)
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Iltimos, yetkazib berish va to'lov ma'lumotlarini to'liq kiriting.
        </p>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-300 text-red-700 rounded-xl text-xs font-bold flex items-center space-x-2">
          <AlertCircle className="w-5 h-5 shrink-0 text-red-600" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8" noValidate>
        {/* Left Form: Delivery & Customer Info */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider font-sans border-b border-slate-100 pb-3 flex items-center space-x-2">
              <Truck className="w-4 h-4 text-amber-500" />
              <span>1. Yetkazib berish ma'lumotlari</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Ism va Familiya: <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="Aziz Ravshanov"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className={`w-full bg-slate-50 border rounded-xl p-3 text-xs outline-none focus:border-amber-500 ${
                    attempted && !customerName.trim() ? 'border-red-500 bg-red-50/40 ring-1 ring-red-500' : 'border-slate-300'
                  }`}
                />
                {attempted && !customerName.trim() && (
                  <span className="text-[10px] text-red-600 font-bold mt-1 block">
                    To'ldirish shart!
                  </span>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Telefon raqami (+998): <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="+998 90 123 45 67"
                  value={phone}
                  onChange={(e) => handlePhoneChange(e.target.value)}
                  className={`w-full bg-slate-50 border rounded-xl p-3 text-xs font-semibold outline-none focus:border-amber-500 ${
                    attempted && (!phone.trim() || phone.trim() === '+998') ? 'border-red-500 bg-red-50/40 ring-1 ring-red-500' : 'border-slate-300'
                  }`}
                />
                {attempted && (!phone.trim() || phone.trim() === '+998') && (
                  <span className="text-[10px] text-red-600 font-bold mt-1 block">
                    To'ldirish shart!
                  </span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Shahar / Viloyat: <span className="text-red-500">*</span>
                </label>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-semibold outline-none"
                >
                  <option value="Toshkent">Toshkent shahri</option>
                  <option value="Samarqand">Samarqand</option>
                  <option value="Buxoro">Buxoro</option>
                  <option value="Namangan">Namangan</option>
                  <option value="Andijon">Andijon</option>
                  <option value="Farg'ona">Farg'ona</option>
                  <option value="Xiva">Xiva / Xorazm</option>
                  <option value="Qarshi">Qarshi / Qashqadaryo</option>
                  <option value="Termiz">Termiz / Surxondaryo</option>
                  <option value="Nukus">Nukus / Qoraqalpog'iston</option>
                  <option value="Navoiy">Navoiy</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Aniq manzil (Ko'cha, uy, xonadon): <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="Chilonzor 12-daha, 4-uy, 15-xonadon"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className={`w-full bg-slate-50 border rounded-xl p-3 text-xs outline-none focus:border-amber-500 ${
                    attempted && !address.trim() ? 'border-red-500 bg-red-50/40 ring-1 ring-red-500' : 'border-slate-300'
                  }`}
                />
                {attempted && !address.trim() && (
                  <span className="text-[10px] text-red-600 font-bold mt-1 block">
                    To'ldirish shart!
                  </span>
                )}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Qo'shimcha izoh (Kuryer uchun):
              </label>
              <textarea
                placeholder="Masalan: Uyda soat 18:00 dan keyin bo'laman..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs outline-none focus:border-amber-500 h-20"
              />
            </div>
          </div>

          {/* Payment Method Selection */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider font-sans border-b border-slate-100 pb-3 flex items-center space-x-2">
              <CreditCard className="w-4 h-4 text-amber-500" />
              <span>2. To'lov usuli</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { id: 'Click', label: 'CLICK', icon: '🔹' },
                { id: 'Payme', label: 'PAYME', icon: '🟢' },
                { id: 'Uzcard/Humo', label: 'UZCARD / HUMO', icon: '💳' },
                { id: 'Naqd', label: 'NAQD (QO\'LGA)', icon: '💵' }
              ].map((pm) => (
                <button
                  key={pm.id}
                  type="button"
                  onClick={() => setPaymentMethod(pm.id as any)}
                  className={`p-3.5 rounded-xl border-2 text-center transition-all ${
                    paymentMethod === pm.id
                      ? 'border-amber-400 bg-amber-50/50 text-slate-950 font-extrabold shadow-sm'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <span className="text-xl block mb-1">{pm.icon}</span>
                  <span className="text-xs uppercase">{pm.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Summary Card */}
        <div className="lg:col-span-5">
          <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-xl space-y-6 sticky top-24">
            <h3 className="font-extrabold text-base tracking-wider uppercase font-sans border-b border-slate-800 pb-3">
              BUYURTMA XULOSASI ({cart.length} ta mahsulot)
            </h3>

            {/* Items scroll */}
            <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
              {cart.map((item) => (
                <div key={item.id} className="flex justify-between items-center text-xs">
                  <div className="flex items-center space-x-2.5 max-w-[70%]">
                    <img src={item.image} alt="" className="w-10 h-10 object-cover rounded-lg shrink-0" />
                    <div className="truncate">
                      <p className="font-bold text-white truncate">{item.name}</p>
                      <p className="text-[10px] text-slate-400">
                        {item.quantity} x {formatPrice(item.price)}
                      </p>
                    </div>
                  </div>
                  <span className="font-black text-amber-400">
                    {formatPrice(item.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>

            <div className="border-t border-slate-800 pt-4 space-y-2 text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Mahsulotlar summasi:</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-400 font-bold">
                  <span>Chegirma:</span>
                  <span>-{formatPrice(discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-300">
                <span>Yetkazib berish:</span>
                <span>{deliveryFee === 0 ? 'BEPUL' : formatPrice(deliveryFee)}</span>
              </div>
              <div className="flex justify-between text-white font-black text-lg pt-2 border-t border-slate-800">
                <span>JAMI:</span>
                <span className="text-amber-400">{formatPrice(total)}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-amber-400 text-slate-950 hover:bg-amber-300 font-black py-4 rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-amber-400/20 transition-all hover:scale-102"
              id="submit-order-btn"
            >
              {isSubmitting ? 'RASMIYLASHTIRILMOQDA...' : 'BUYURTMANI TASDIQLASH'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
