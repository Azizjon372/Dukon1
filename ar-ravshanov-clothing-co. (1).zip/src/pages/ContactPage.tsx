import React, { useState } from 'react';
import { Phone, Mail, MapPin, Send, MessageSquare } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('+998 ');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setName('');
    setPhone('+998 ');
    setMessage('');
    setTimeout(() => setSubmitted(false), 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-12">
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900 uppercase font-sans">
          ALOQA VA MANZILIMIZ
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Savol va takliflaringiz bo'lsa, biz bilan bog'laning.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Contact Info Card */}
        <div className="bg-slate-900 text-white p-8 rounded-2xl border border-slate-800 space-y-6">
          <h3 className="font-extrabold text-amber-400 text-lg uppercase font-sans">
            BIZ BILAN BOG'LANISH
          </h3>

          <div className="space-y-4 text-xs">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 bg-slate-800 rounded-lg flex items-center justify-center text-amber-400">
                <Phone className="w-4 h-4" />
              </div>
              <div>
                <p className="text-slate-400 font-semibold">Telefon raqam:</p>
                <p className="font-bold text-white text-sm">+998 90 123 45 67</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 bg-slate-800 rounded-lg flex items-center justify-center text-amber-400">
                <Mail className="w-4 h-4" />
              </div>
              <div>
                <p className="text-slate-400 font-semibold">Email:</p>
                <p className="font-bold text-white text-sm">info@ravshanov.uz</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 bg-slate-800 rounded-lg flex items-center justify-center text-amber-400">
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <p className="text-slate-400 font-semibold">Bosh do'kon manzili:</p>
                <p className="font-bold text-white text-sm">Toshkent sh., Amir Temur ko'chasi 108-uy</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 bg-slate-800 rounded-lg flex items-center justify-center text-amber-400">
                <Send className="w-4 h-4" />
              </div>
              <div>
                <p className="text-slate-400 font-semibold">Telegram:</p>
                <a href="https://t.me/azizravshanov" target="_blank" rel="noreferrer" className="font-bold text-amber-400 hover:underline text-sm">
                  @azizravshanov
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Form Card */}
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="font-extrabold text-slate-900 text-lg uppercase font-sans">
            XABAR YUBORISH
          </h3>

          {submitted && (
            <div className="p-3 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl">
              Xabaringiz muvaffaqiyatli yuborildi! Tez orada javob beramiz.
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Ismingiz:
              </label>
              <input
                type="text"
                placeholder="Aziz Ravshanov"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs outline-none focus:border-amber-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Telefon raqamingiz:
              </label>
              <input
                type="text"
                placeholder="+998 90 123 45 67"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs outline-none focus:border-amber-500 font-semibold"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Xabaringiz:
              </label>
              <textarea
                placeholder="Savol yoki taklifingizni yozing..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs outline-none focus:border-amber-500 h-28"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-slate-900 text-amber-400 hover:bg-slate-800 font-black py-3 rounded-xl text-xs uppercase tracking-wider transition-all"
            >
              YUBORISH
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
