import React from 'react';
import { ShieldCheck, Award, Users, MapPin } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-12">
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold text-amber-500 uppercase tracking-widest bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
          AR RAVSHANOV CLOTHING CO.
        </span>
        <h1 className="text-3xl sm:text-5xl font-black text-slate-900 uppercase font-sans tracking-tight">
          KOMPANIYA HAQIDA
        </h1>
        <p className="text-sm text-slate-600 leading-relaxed font-medium">
          AR Ravshanov Clothing Co. — O'zbekistondagi premium kiyim-kechak, charmdan kurtkalar va aksessuarlar ishlab chiqaruvchi yetakchi milliy brend. Biz har bir detalda sifat, bejirim dizayn va qulaylikni ta'minlaymiz.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs text-center space-y-3">
          <div className="w-12 h-12 bg-amber-400/20 text-amber-500 rounded-xl flex items-center justify-center mx-auto text-xl">
            👑
          </div>
          <h3 className="font-black text-slate-900 text-lg uppercase font-sans">
            AZIZ RAVSHANOV DIZAYNI
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Asoschi va bosh dizayner Aziz Ravshanov rahbarligida barcha kolleksiyalar xalqaro moda tendensiyalariga mos holda yaratiladi.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs text-center space-y-3">
          <div className="w-12 h-12 bg-amber-400/20 text-amber-500 rounded-xl flex items-center justify-center mx-auto text-xl">
            ✨
          </div>
          <h3 className="font-black text-slate-900 text-lg uppercase font-sans">
            TABIIY MATOLAR
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            100% Paxta, ipak va Yevropa standartlariga javob beradigan tabiiy charm materiallaridan foydalanamiz.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs text-center space-y-3">
          <div className="w-12 h-12 bg-amber-400/20 text-amber-500 rounded-xl flex items-center justify-center mx-auto text-xl">
            🚀
          </div>
          <h3 className="font-black text-slate-900 text-lg uppercase font-sans">
            ISHLAB CHIQARISH VOB
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Zamonaviy texnologiyalar va tajribali tikuvchilarimiz evaziga yuqori darajadagi tikuv sifatini kafolatlaymiz.
          </p>
        </div>
      </div>
    </div>
  );
};
