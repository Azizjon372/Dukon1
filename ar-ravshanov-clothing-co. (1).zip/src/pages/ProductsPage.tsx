import React, { useState, useEffect } from 'react';
import { Search, Filter, SlidersHorizontal, RotateCcw } from 'lucide-react';
import { Product, Category } from '../types';
import { ProductCard } from '../components/ProductCard';
import { fetchProducts } from '../services/api';

interface ProductsPageProps {
  categories: Category[];
  initialCategory?: string;
  initialSearch?: string;
  onViewDetails: (product: Product) => void;
}

export const ProductsPage: React.FC<ProductsPageProps> = ({
  categories,
  initialCategory = 'barchasi',
  initialSearch = '',
  onViewDetails
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState(initialSearch);
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [sortBy, setSortBy] = useState('newest');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  useEffect(() => {
    setSelectedCategory(initialCategory);
  }, [initialCategory]);

  useEffect(() => {
    setSearch(initialSearch);
  }, [initialSearch]);

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await fetchProducts({
        search,
        category: selectedCategory,
        sortBy,
        minPrice,
        maxPrice,
        page,
        limit: 12
      });
      setProducts(res.products);
      setTotalPages(res.totalPages);
      setTotalCount(res.total);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedCategory, sortBy, page]);

  const handleApplyFilter = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    loadData();
  };

  const handleReset = () => {
    setSearch('');
    setSelectedCategory('barchasi');
    setSortBy('newest');
    setMinPrice('');
    setMaxPrice('');
    setPage(1);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 space-y-6">
      {/* Page Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 uppercase font-sans tracking-wide">
            MAHSULOTLAR KATALOGI
          </h1>
          <p className="text-xs text-slate-500 mt-1 font-medium">
            Jami {totalCount} ta mahsulot topildi
          </p>
        </div>

        {/* Search & Sort Header */}
        <div className="flex items-center space-x-3">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-amber-500 shadow-xs"
          >
            <option value="newest">Tartiblash: Yangi kelganlar</option>
            <option value="price_asc">Narx: Arzondan Qimmatga</option>
            <option value="price_desc">Narx: Qimmatdan Arzonga</option>
            <option value="rating">Reyting: Yuqorilar</option>
          </select>
        </div>
      </div>

      {/* Main Catalog Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Filters */}
        <div className="space-y-6 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs h-fit">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <span className="font-extrabold text-slate-900 text-xs uppercase tracking-wider flex items-center space-x-2">
              <Filter className="w-4 h-4 text-amber-500" />
              <span>FILTERLASH</span>
            </span>
            <button
              onClick={handleReset}
              className="text-[11px] text-slate-400 hover:text-red-500 flex items-center space-x-1 font-semibold"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Tozalash</span>
            </button>
          </div>

          <form onSubmit={handleApplyFilter} className="space-y-5">
            {/* Search */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Qidiruv:
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Nomi bo'yicha..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl py-2 pl-3 pr-8 text-xs outline-none focus:border-amber-500"
                />
                <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400">
                  <Search className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Categories */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-2">
                Kategoriyalar:
              </label>
              <div className="space-y-1">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCategory('barchasi');
                    setPage(1);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                    selectedCategory === 'barchasi'
                      ? 'bg-slate-900 text-amber-400'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  Barcha kategoriyalar
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => {
                      setSelectedCategory(cat.name);
                      setPage(1);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-bold transition-all flex justify-between items-center ${
                      selectedCategory.toLowerCase() === cat.name.toLowerCase()
                        ? 'bg-slate-900 text-amber-400'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <span>{cat.name}</span>
                    <span className="text-[10px] opacity-70">({cat.productCount || 0})</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-2">
                Narx oralig'i (UZS):
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  placeholder="Min narx"
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value)}
                  className="bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs outline-none focus:border-amber-500"
                />
                <input
                  type="number"
                  placeholder="Max narx"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                  className="bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-amber-400 text-slate-950 hover:bg-amber-300 font-extrabold py-2.5 rounded-xl text-xs uppercase tracking-wider transition-all"
            >
              FILTERLASH
            </button>
          </form>
        </div>

        {/* Product Grid Area */}
        <div className="lg:col-span-3 space-y-6">
          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 sm:gap-6">
              {[1, 2, 3, 4, 5, 6].map((n) => (
                <div key={n} className="bg-slate-200 rounded-2xl aspect-3/4 animate-pulse" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-slate-300 p-8">
              <p className="text-base font-bold text-slate-700">Hech qanday mahsulot topilmadi</p>
              <p className="text-xs text-slate-400 mt-1">
                Filterlarni o'zgartirib qaytadan urining.
              </p>
              <button
                onClick={handleReset}
                className="mt-4 bg-slate-900 text-amber-400 px-4 py-2 rounded-xl text-xs font-bold uppercase"
              >
                Filterlarni tozalash
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 sm:gap-6">
              {products.map((p) => (
                <ProductCard key={p.id} product={p} onViewDetails={onViewDetails} />
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center space-x-2 pt-6">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((pNum) => (
                <button
                  key={pNum}
                  onClick={() => setPage(pNum)}
                  className={`w-9 h-9 rounded-xl text-xs font-bold border transition-all ${
                    page === pNum
                      ? 'bg-slate-900 text-amber-400 border-slate-900 shadow-sm'
                      : 'bg-white text-slate-700 border-slate-300 hover:border-slate-500'
                  }`}
                >
                  {pNum}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
