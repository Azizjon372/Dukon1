import React, { useState, useEffect } from 'react';
import { User, Package, Clock, Truck, CheckCircle2, XCircle, MapPin, Phone, Save } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { fetchMyOrders } from '../services/api';
import { Order, OrderStatus } from '../types';
import { formatUzPhone } from '../lib/utils';

export const AccountPage: React.FC = () => {
  const { user, updateProfile } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(true);

  const [fullName, setFullName] = useState(user?.fullName || '');
  const [phone, setPhone] = useState(user?.phone ? formatUzPhone(user.phone) : '+998 ');
  const [city, setCity] = useState(user?.city || 'Toshkent');
  const [address, setAddress] = useState(user?.address || '');
  const [isUpdating, setIsUpdating] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [selectedTrackOrder, setSelectedTrackOrder] = useState<Order | null>(null);

  useEffect(() => {
    fetchMyOrders()
      .then(setOrders)
      .catch(console.error)
      .finally(() => setLoadingOrders(false));
  }, []);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) return;
    setIsUpdating(true);
    setSuccessMsg('');
    try {
      await updateProfile({ fullName, phone, city, address });
      setSuccessMsg('Profil ma\'lumotlari yangilandi!');
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      alert(err.message || 'Xatolik yuz berdi');
    } finally {
      setIsUpdating(false);
    }
  };

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'Yangi':
        return <span className="bg-blue-100 text-blue-800 text-[11px] font-bold px-2.5 py-1 rounded-md">Yangi</span>;
      case 'Tasdiqlangan':
        return <span className="bg-indigo-100 text-indigo-800 text-[11px] font-bold px-2.5 py-1 rounded-md">Tasdiqlandi</span>;
      case 'Tayyorlanmoqda':
        return <span className="bg-amber-100 text-amber-800 text-[11px] font-bold px-2.5 py-1 rounded-md">Tayyorlanmoqda</span>;
      case 'Yuborildi':
        return <span className="bg-purple-100 text-purple-800 text-[11px] font-bold px-2.5 py-1 rounded-md">Yuborildi</span>;
      case 'Yetkazildi':
        return <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2.5 py-1 rounded-md">Yetkazib berildi</span>;
      case 'Bekor qilindi':
        return <span className="bg-red-100 text-red-800 text-[11px] font-bold px-2.5 py-1 rounded-md">Bekor qilindi</span>;
      default:
        return <span className="bg-slate-100 text-slate-800 text-[11px] font-bold px-2.5 py-1 rounded-md">{status}</span>;
    }
  };

  const formatPrice = (price: number) => price.toLocaleString('uz-UZ') + ' UZS';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 space-y-8">
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 uppercase font-sans">
          SHAXSIY MABLAG' VA SHAXSIY KABINET
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Profilingiz va buyurtmalar tarixingizni boshqaring.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Profile Form */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider font-sans border-b border-slate-100 pb-3 flex items-center space-x-2">
              <User className="w-4 h-4 text-amber-500" />
              <span>Profil ma'lumotlari</span>
            </h3>

            {successMsg && (
              <div className="p-3 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl">
                {successMsg}
              </div>
            )}

            <form onSubmit={handleUpdateProfile} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Ism va Familiya:
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Email (O'zgartirib bo'lmaydi):
                </label>
                <input
                  type="email"
                  value={user?.email || ''}
                  disabled
                  className="w-full bg-slate-100 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-500 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Telefon:
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(formatUzPhone(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs outline-none focus:border-amber-500 font-semibold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Shahar:
                </label>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs outline-none"
                >
                  <option value="Toshkent">Toshkent</option>
                  <option value="Samarqand">Samarqand</option>
                  <option value="Buxoro">Buxoro</option>
                  <option value="Namangan">Namangan</option>
                  <option value="Andijon">Andijon</option>
                  <option value="Farg'ona">Farg'ona</option>
                  <option value="Xiva">Xiva</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Aniq manzil:
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs outline-none focus:border-amber-500"
                />
              </div>

              <button
                type="submit"
                disabled={isUpdating}
                className="w-full bg-slate-900 text-white hover:bg-amber-400 hover:text-slate-950 font-black py-3 rounded-xl text-xs uppercase tracking-wider transition-all shadow-sm flex items-center justify-center space-x-2"
              >
                <Save className="w-4 h-4" />
                <span>{isUpdating ? 'Saqlanmoqda...' : 'O\'zgarishlarni Saqlash'}</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Order History */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider font-sans border-b border-slate-100 pb-3 flex items-center space-x-2">
              <Package className="w-4 h-4 text-amber-500" />
              <span>Buyurtmalarim tarixi ({orders.length})</span>
            </h3>

            {loadingOrders ? (
              <p className="text-xs text-slate-400 py-6 text-center">Yuklanmoqda...</p>
            ) : orders.length === 0 ? (
              <div className="text-center py-12 text-slate-500 space-y-2">
                <p className="text-sm font-bold">Sizda hali buyurtmalar yo'q</p>
                <p className="text-xs text-slate-400">
                  Bizning do'konimizdan birinchi kiyimingizni xarid qiling!
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((ord) => (
                  <div
                    key={ord.id}
                    className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-200/60 pb-2">
                      <div>
                        <span className="font-mono text-amber-600 font-extrabold text-sm">
                          {ord.id}
                        </span>
                        <span className="text-[11px] text-slate-400 ml-2">
                          {new Date(ord.createdAt).toLocaleString('uz-UZ')}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {getStatusBadge(ord.status)}
                        <button
                          onClick={() => setSelectedTrackOrder(ord)}
                          className="text-xs bg-slate-900 text-white px-3 py-1 rounded-md font-bold hover:bg-amber-400 hover:text-slate-950 transition-colors"
                        >
                          Kuzatish (Track)
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-slate-500">Mahsulotlar:</span>
                        <p className="font-semibold text-slate-800">
                          {ord.items.map((i) => `${i.name} (${i.quantity}x)`).join(', ')}
                        </p>
                      </div>
                      <div>
                        <span className="text-slate-500">Jami summasi:</span>
                        <p className="font-extrabold text-slate-900">{formatPrice(ord.total)}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Track Order Modal */}
      {selectedTrackOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl p-6 border border-slate-200 space-y-6">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-extrabold text-slate-900 text-base font-sans">
                  BUYURTMA HOLATI: {selectedTrackOrder.id}
                </h3>
                <p className="text-xs text-slate-400">
                  {new Date(selectedTrackOrder.createdAt).toLocaleString('uz-UZ')}
                </p>
              </div>
              <button
                onClick={() => setSelectedTrackOrder(null)}
                className="text-slate-400 hover:text-slate-900 font-bold text-lg"
              >
                ✕
              </button>
            </div>

            {/* Live Progress Steps */}
            <div className="space-y-4">
              {[
                { status: 'Yangi', label: 'Buyurtma qabul qilindi' },
                { status: 'Tasdiqlangan', label: 'Operator tomonidan tasdiqlandi' },
                { status: 'Tayyorlanmoqda', label: 'Omborda qadoqlanmoqda' },
                { status: 'Yuborildi', label: 'Kuryerga topshirildi' },
                { status: 'Yetkazildi', label: 'Mijozga yetkazib berildi' }
              ].map((step, idx) => {
                const statusesOrder = ['Yangi', 'Tasdiqlangan', 'Tayyorlanmoqda', 'Yuborildi', 'Yetkazildi'];
                const currentIdx = statusesOrder.indexOf(selectedTrackOrder.status);
                const stepIdx = statusesOrder.indexOf(step.status);
                const isDone = stepIdx <= currentIdx && selectedTrackOrder.status !== 'Bekor qilindi';

                return (
                  <div key={idx} className="flex items-center space-x-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                        isDone
                          ? 'bg-emerald-500 text-white'
                          : 'bg-slate-100 text-slate-400 border border-slate-200'
                      }`}
                    >
                      {isDone ? '✓' : idx + 1}
                    </div>
                    <span className={`text-xs font-semibold ${isDone ? 'text-slate-900 font-bold' : 'text-slate-400'}`}>
                      {step.label}
                    </span>
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => setSelectedTrackOrder(null)}
              className="w-full bg-slate-900 text-white font-bold py-2.5 rounded-xl text-xs uppercase"
            >
              Yopish
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
