import React from 'react';
import { Hero } from '../components/Hero';
import { ProductGrid } from '../components/ProductGrid';
import { CategorySection } from '../components/CategorySection';
import { Product, Category } from '../types';
import { Star, ShieldCheck, Truck, RefreshCw, ArrowRight } from 'lucide-react';

interface HomePageProps {
  products: Product[];
  categories: Category[];
  onViewDetails: (product: Product) => void;
  onSelectCategory: (cat: string) => void;
  setCurrentTab: (tab: string) => void;
  isLoading?: boolean;
}

export const HomePage: React.FC<HomePageProps> = ({
  products,
  categories,
  onViewDetails,
  onSelectCategory,
  setCurrentTab,
  isLoading
}) => {
  const featured = products.filter((p) => p.isFeatured).slice(0, 4);
  const bestSellers = products.filter((p) => p.isBestSeller).slice(0, 4);

  return (
    <div className="space-y-8 bg-slate-50 min-h-screen pb-12">
      {/* Hero Banner */}
      <Hero onShopClick={() => setCurrentTab('products')} />

      {/* Editorial Overview Stats Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 pt-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs">
            <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-1">Umumiy tushum</p>
            <p className="text-2xl font-serif font-black text-slate-900">$124,500</p>
            <p className="text-[10px] text-emerald-500 font-bold mt-2">+12.5% BU OYDA</p>
          </div>
          <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs">
            <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-1">Buyurtmalar</p>
            <p className="text-2xl font-serif font-black text-slate-900">1,482</p>
            <p className="text-[10px] text-emerald-500 font-bold mt-2">+8.3% BU OYDA</p>
          </div>
          <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs">
            <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-1">Mijozlar</p>
            <p className="text-2xl font-serif font-black text-slate-900">9,210</p>
            <p className="text-[10px] text-indigo-500 font-bold mt-2">+4.1% BU OYDA</p>
          </div>
          <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs">
            <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-1">Konversiya</p>
            <p className="text-2xl font-serif font-black text-slate-900">3.24%</p>
            <p className="text-[10px] text-rose-500 font-bold mt-2">-0.4% KECHA</p>
          </div>
        </div>
      </div>

      {/* Featured Products: "YANGI KELGANLAR" matching screenshot */}
      <ProductGrid
        title="YANGI KELGANLAR"
        subtitle="So'nggi 2026-yilgi premium erkaklar va ayollar kolleksiyalari"
        products={featured.length > 0 ? featured : products.slice(0, 4)}
        onViewDetails={onViewDetails}
        isLoading={isLoading}
      />

      {/* Top Brands & Categories */}
      <CategorySection
        categories={categories}
        onSelectCategory={onSelectCategory}
      />

      {/* Best Sellers Section */}
      <ProductGrid
        title="ENG KO'P SOTILGANLAR (BEST SELLERS)"
        subtitle="Mijozlarimiz tomonidan eng yuqori baholangan libos va soatlar"
        products={bestSellers.length > 0 ? bestSellers : products.slice(0, 4)}
        onViewDetails={onViewDetails}
        isLoading={isLoading}
      />

      {/* Why Choose Us Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8 py-8">
        <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 relative overflow-hidden shadow-2xl border border-slate-800">
          <div className="absolute top-0 right-0 w-96 h-96 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 text-center max-w-2xl mx-auto space-y-4">
            <span className="text-xs font-bold text-amber-400 tracking-widest uppercase bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/30">
              NEGA BIZNI TANLASHADI?
            </span>
            <h2 className="text-2xl sm:text-4xl font-black uppercase tracking-tight font-sans">
              SIFAT VA ISHONCH BIZNING OLIY MAQSADIMIZ
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              AR Ravshanov brendi ostida ishlab chiqarilgan barcha mahsulotlar 100% sifat nazoratidan o'tadi.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-10 relative z-10">
            <div className="p-6 bg-slate-800/60 rounded-2xl border border-slate-700/60 text-center space-y-3 backdrop-blur-xs">
              <div className="w-12 h-12 bg-amber-400/20 text-amber-400 rounded-xl flex items-center justify-center mx-auto text-xl">
                🚚
              </div>
              <h3 className="font-extrabold text-white text-base">TEZKOR YETKAZISH</h3>
              <p className="text-xs text-slate-400">
                Toshkent bo'yicha 24 soat ichida, viloyatlarga 2-3 kunda kuryer orqali eshigingizgacha.
              </p>
            </div>

            <div className="p-6 bg-slate-800/60 rounded-2xl border border-slate-700/60 text-center space-y-3 backdrop-blur-xs">
              <div className="w-12 h-12 bg-amber-400/20 text-amber-400 rounded-xl flex items-center justify-center mx-auto text-xl">
                ✨
              </div>
              <h3 className="font-extrabold text-white text-base">PREMIUM MATERIAL</h3>
              <p className="text-xs text-slate-400">
                Faqatgina 100% tabiiy paxta va charm matolardan foydalaniladi.
              </p>
            </div>

            <div className="p-6 bg-slate-800/60 rounded-2xl border border-slate-700/60 text-center space-y-3 backdrop-blur-xs">
              <div className="w-12 h-12 bg-amber-400/20 text-amber-400 rounded-xl flex items-center justify-center mx-auto text-xl">
                💳
              </div>
              <h3 className="font-extrabold text-white text-base">XAVFSIZ TO'LOV</h3>
              <p className="text-xs text-slate-400">
                Click, Payme, Uzcard orqali yoki mahsulotni qo'lingizga olgandan so'ng naqd to'lang.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Promo Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 rounded-2xl p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-1 text-center sm:text-left">
            <span className="text-xs font-black uppercase tracking-widest bg-slate-950 text-amber-400 px-2.5 py-1 rounded">
              MAXSUS TAKLIF
            </span>
            <h3 className="text-2xl sm:text-3xl font-black uppercase font-sans tracking-tight">
              KOLLEKSIYAMIZDAN BARCHA MAHSULOTLARGA -20% CHEGIRMA!
            </h3>
            <p className="text-xs font-bold text-slate-900">
              Promokod: <strong className="bg-white px-2 py-0.5 rounded shadow-xs font-mono">RAVSHANOV10</strong>
            </p>
          </div>
          <button
            onClick={() => setCurrentTab('products')}
            className="bg-slate-950 text-white hover:bg-slate-900 font-extrabold px-8 py-3.5 rounded-xl text-xs uppercase tracking-wider flex items-center space-x-2 shrink-0 transition-transform hover:scale-105 active:scale-95 shadow-lg"
          >
            <span>HOZIR SOTIB OLISH</span>
            <ArrowRight className="w-4 h-4 text-amber-400" />
          </button>
        </div>
      </section>
    </div>
  );
};
