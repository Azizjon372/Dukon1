import React, { useState, useEffect } from 'react';
import { Search, Eye, Filter, CheckCircle, Clock, Truck } from 'lucide-react';
import { Order, OrderStatus } from '../types';
import { fetchAdminOrders, updateOrderStatus } from '../services/api';

export const AdminOrders: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>('barchasi');
  const [search, setSearch] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const loadOrders = async () => {
    setLoading(true);
    try {
      const res = await fetchAdminOrders();
      setOrders(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, []);

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    try {
      const updated = await updateOrderStatus(orderId, newStatus);
      setOrders((prev) => prev.map((o) => (o.id === orderId ? updated : o)));
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder(updated);
      }
    } catch (err: any) {
      alert(err.message || 'Statusni o\'zgartirishda xatolik');
    }
  };

  const statuses: OrderStatus[] = [
    'Yangi',
    'Tasdiqlangan',
    'Tayyorlanmoqda',
    'Yuborildi',
    'Yetkazildi',
    'Bekor qilindi'
  ];

  const formatPrice = (price: number) => price.toLocaleString('uz-UZ') + ' UZS';

  const filteredOrders = orders.filter((o) => {
    const matchStatus = statusFilter === 'barchasi' || o.status === statusFilter;
    const matchSearch =
      o.id.toLowerCase().includes(search.toLowerCase()) ||
      o.customerName.toLowerCase().includes(search.toLowerCase()) ||
      o.phone.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-black text-slate-900 uppercase font-sans tracking-tight">
            BUYURTMALAR BOSHQARUVI
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Mijozlar buyurtmalari va ularning holatini boshqaring.
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Buyurtma ID, Ism yoki Telefon..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl py-2 pl-9 pr-3 text-xs outline-none"
          />
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-bold text-slate-500">Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800"
          >
            <option value="barchasi">Barcha Statuslar</option>
            {statuses.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900 text-white uppercase font-bold text-[10px]">
              <tr>
                <th className="p-3.5">Order ID</th>
                <th className="p-3.5">Mijoz</th>
                <th className="p-3.5">Telefon</th>
                <th className="p-3.5">Shahar / Manzil</th>
                <th className="p-3.5">Jami Summa</th>
                <th className="p-3.5">To'lov</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Tafsilot</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">Yuklanmoqda...</td>
                </tr>
              ) : filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">Buyurtma topilmadi</td>
                </tr>
              ) : (
                filteredOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-50">
                    <td className="p-3.5 font-mono font-extrabold text-amber-600">{ord.id}</td>
                    <td className="p-3.5 font-bold text-slate-900">{ord.customerName}</td>
                    <td className="p-3.5 text-slate-600">{ord.phone}</td>
                    <td className="p-3.5 text-slate-600 truncate max-w-[150px]">{ord.city}, {ord.address}</td>
                    <td className="p-3.5 font-black text-slate-900">{formatPrice(ord.total)}</td>
                    <td className="p-3.5 text-slate-700 font-semibold">{ord.paymentMethod}</td>
                    <td className="p-3.5">
                      <select
                        value={ord.status}
                        onChange={(e) => handleStatusChange(ord.id, e.target.value)}
                        className="bg-slate-100 border border-slate-300 rounded-lg text-[11px] font-bold p-1 outline-none"
                      >
                        {statuses.map((st) => (
                          <option key={st} value={st}>{st}</option>
                        ))}
                      </select>
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => setSelectedOrder(ord)}
                        className="p-1.5 bg-slate-900 text-amber-400 hover:bg-slate-800 rounded-lg transition-colors font-bold"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white w-full max-w-xl rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="font-extrabold text-slate-900 text-sm uppercase">
                BUYURTMA TAFSILOTLARI: {selectedOrder.id}
              </h3>
              <button onClick={() => setSelectedOrder(null)} className="font-bold">✕</button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-xl border">
                <p><strong>Mijoz:</strong> {selectedOrder.customerName}</p>
                <p><strong>Telefon:</strong> {selectedOrder.phone}</p>
                <p><strong>Shahar:</strong> {selectedOrder.city}</p>
                <p><strong>Manzil:</strong> {selectedOrder.address}</p>
                <p><strong>To'lov Usuli:</strong> {selectedOrder.paymentMethod}</p>
                <p><strong>Kanal/Promokod:</strong> {selectedOrder.promoCode || 'Mavjud emas'}</p>
              </div>

              <div>
                <strong className="block mb-2 uppercase">Buyurtma Qilingan Mahsulotlar:</strong>
                <div className="space-y-2">
                  {selectedOrder.items.map((it) => (
                    <div key={it.id} className="flex justify-between items-center bg-slate-100 p-2.5 rounded-xl">
                      <div className="flex items-center space-x-2">
                        <img src={it.image} alt="" className="w-8 h-8 object-cover rounded" />
                        <div>
                          <p className="font-bold">{it.name}</p>
                          <p className="text-[10px] text-slate-500">Size: {it.selectedSize} | Qty: {it.quantity}</p>
                        </div>
                      </div>
                      <span className="font-bold">{formatPrice(it.price * it.quantity)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-2 space-y-1 font-semibold">
                <div className="flex justify-between"><span>Summa:</span><span>{formatPrice(selectedOrder.subtotal)}</span></div>
                <div className="flex justify-between"><span>Yetkazish:</span><span>{formatPrice(selectedOrder.deliveryFee)}</span></div>
                <div className="flex justify-between text-amber-600 font-extrabold text-sm pt-1">
                  <span>Jami To'lov:</span><span>{formatPrice(selectedOrder.total)}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setSelectedOrder(null)}
              className="w-full bg-slate-900 text-white font-bold py-2.5 rounded-xl uppercase text-xs"
            >
              Yopish
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
