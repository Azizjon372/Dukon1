import React, { useState } from 'react';
import {
  LayoutDashboard,
  ShoppingBag,
  Layers,
  FileText,
  Users,
  Star,
  Tag,
  Settings,
  Store,
  LogOut,
  ShieldCheck,
  Menu,
  X,
  Bell
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AdminDashboard } from './AdminDashboard';
import { AdminProducts } from './AdminProducts';
import { AdminCategories } from './AdminCategories';
import { AdminOrders } from './AdminOrders';
import { AdminCustomers } from './AdminCustomers';
import { AdminReviews } from './AdminReviews';
import { AdminDiscounts } from './AdminDiscounts';
import { AdminSettings } from './AdminSettings';

interface AdminLayoutProps {
  onBackToStore: () => void;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({ onBackToStore }) => {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'products', label: 'Mahsulotlar', icon: ShoppingBag },
    { id: 'categories', label: 'Kategoriyalar', icon: Layers },
    { id: 'orders', label: 'Buyurtmalar', icon: FileText },
    { id: 'customers', label: 'Mijozlar', icon: Users },
    { id: 'reviews', label: 'Sharhlar', icon: Star },
    { id: 'discounts', label: 'Promokodlar', icon: Tag },
    { id: 'settings', label: 'Sozlamalar', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-100 flex font-sans text-slate-800">
      {/* Sidebar Desktop */}
      <aside className="hidden lg:flex lg:w-64 bg-slate-950 text-white flex-col border-r border-slate-800 shrink-0">
        {/* Brand Header matching Editorial Aesthetic */}
        <div className="p-8 border-b border-slate-800 mb-4">
          <h1 className="text-xl font-serif font-bold text-white tracking-tight italic uppercase">
            Aziz Ravshanov
          </h1>
          <p className="text-[10px] text-slate-500 font-medium tracking-[0.2em] mt-1 uppercase">
            FULL-STACK DEVELOPER
          </p>
        </div>

        {/* Nav Links */}
        <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all ${
                  isActive
                    ? 'bg-amber-400 text-slate-950 shadow-md font-black'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 space-y-2">
          <button
            onClick={onBackToStore}
            className="w-full flex items-center justify-center space-x-2 bg-slate-900 hover:bg-slate-800 text-amber-400 py-2.5 rounded-xl text-xs font-extrabold uppercase transition-colors"
          >
            <Store className="w-4 h-4" />
            <span>Do'konga qaytish</span>
          </button>

          <button
            onClick={() => {
              logout();
              onBackToStore();
            }}
            className="w-full flex items-center justify-center space-x-2 text-red-400 hover:bg-red-500/10 py-2 rounded-xl text-xs font-extrabold uppercase transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Chiqish (Logout)</span>
          </button>
        </div>
      </aside>

      {/* Main Content Container */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-20 shadow-xs">
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden text-slate-700 p-1"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <div className="hidden sm:block">
              <span className="text-[11px] font-bold text-slate-400 uppercase">Tizim holati:</span>
              <span className="ml-2 text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                ● Onlayn (Active)
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="text-xs font-extrabold text-slate-900">{user?.fullName || 'Aziz Ravshanov'}</p>
              <p className="text-[10px] font-bold text-amber-600 uppercase">Bosh Admin</p>
            </div>
            <div className="w-9 h-9 bg-slate-900 text-amber-400 font-extrabold rounded-xl flex items-center justify-center text-xs border border-slate-800 shadow-sm">
              AR
            </div>
          </div>
        </header>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-slate-950 text-white p-4 space-y-2 border-b border-slate-800">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 px-4 py-2.5 rounded-xl text-xs font-bold uppercase ${
                    activeTab === item.id ? 'bg-amber-400 text-slate-950 font-black' : 'text-slate-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
            <button
              onClick={onBackToStore}
              className="w-full text-left px-4 py-2 text-xs font-bold text-amber-400 uppercase pt-2"
            >
              Do'konga qaytish
            </button>
          </div>
        )}

        {/* Main Content Body */}
        <main className="p-6 sm:p-8 flex-1 overflow-y-auto">
          {activeTab === 'dashboard' && <AdminDashboard />}
          {activeTab === 'products' && <AdminProducts />}
          {activeTab === 'categories' && <AdminCategories />}
          {activeTab === 'orders' && <AdminOrders />}
          {activeTab === 'customers' && <AdminCustomers />}
          {activeTab === 'reviews' && <AdminReviews />}
          {activeTab === 'discounts' && <AdminDiscounts />}
          {activeTab === 'settings' && <AdminSettings />}
        </main>
      </div>
    </div>
  );
};
