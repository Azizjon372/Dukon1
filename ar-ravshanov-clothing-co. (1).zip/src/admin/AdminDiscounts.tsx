import React, { useState, useEffect } from 'react';
import { Plus, Tag, Trash2, CheckCircle } from 'lucide-react';
import { DiscountCode } from '../types';
import { fetchDiscounts, createDiscount, deleteDiscount } from '../services/api';

export const AdminDiscounts: React.FC = () => {
  const [discounts, setDiscounts] = useState<DiscountCode[]>([]);
  const [loading, setLoading] = useState(true);

  const [code, setCode] = useState('');
  const [type, setType] = useState<'percent' | 'fixed'>('percent');
  const [value, setValue] = useState('');
  const [minOrder, setMinOrder] = useState('');

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await fetchDiscounts();
      setDiscounts(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !value) return;

    try {
      await createDiscount({
        code: code.trim().toUpperCase(),
        type,
        value: Number(value),
        minOrderAmount: minOrder ? Number(minOrder) : 0,
        isActive: true
      });
      setCode('');
      setValue('');
      setMinOrder('');
      loadData();
    } catch (err: any) {
      alert(err.message || 'Xatolik');
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Promokodni o\'chirmoqchimisiz?')) {
      try {
        await deleteDiscount(id);
        loadData();
      } catch (err: any) {
        alert(err.message || 'Xatolik');
      }
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-slate-900 uppercase font-sans tracking-tight">
          CHEGIRMA VA PROMOKODLAR BOSHQARUVI
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Xaridorlar uchun promokodlar yarating va faollashtiring.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Create Form */}
        <div className="lg:col-span-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="font-extrabold text-slate-900 text-sm uppercase border-b pb-2">
            YANGI PROMOKOD YARATISH
          </h3>

          <form onSubmit={handleCreate} className="space-y-3 text-xs">
            <div>
              <label className="block font-bold mb-1">Promokod Nomi (Code):</label>
              <input
                type="text"
                placeholder="Masalan: RAVSHANOV10"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full bg-slate-50 border p-2.5 rounded-xl uppercase font-mono font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-bold mb-1">Chegirma Turi:</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full bg-slate-50 border p-2.5 rounded-xl font-bold"
              >
                <option value="percent">Foizda (%)</option>
                <option value="fixed">Aniq summasida (UZS)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold mb-1">Chegirma Miqdori:</label>
              <input
                type="number"
                placeholder={type === 'percent' ? '10 (%)' : '50000 (UZS)'}
                value={value}
                onChange={(e) => setValue(e.target.value)}
                className="w-full bg-slate-50 border p-2.5 rounded-xl font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-bold mb-1">Minimal Buyurtma Summasi (UZS):</label>
              <input
                type="number"
                placeholder="0 (cheklovsiz)"
                value={minOrder}
                onChange={(e) => setMinOrder(e.target.value)}
                className="w-full bg-slate-50 border p-2.5 rounded-xl"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-amber-400 text-slate-950 font-black py-3 rounded-xl uppercase"
            >
              Yaratish
            </button>
          </form>
        </div>

        {/* Discounts List */}
        <div className="lg:col-span-8 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="font-extrabold text-slate-900 text-sm uppercase border-b pb-2">
            MAVJUD PROMOKODLAR ({discounts.length})
          </h3>

          <div className="space-y-3">
            {discounts.map((d) => (
              <div key={d.id} className="p-4 bg-slate-50 border rounded-xl flex justify-between items-center text-xs">
                <div>
                  <span className="font-mono font-black text-amber-600 text-sm bg-amber-100 px-2 py-0.5 rounded">
                    {d.code}
                  </span>
                  <p className="font-bold text-slate-900 mt-1">
                    Chegirma: {d.type === 'percent' ? `${d.value}%` : `${d.value.toLocaleString()} UZS`}
                  </p>
                  <p className="text-[10px] text-slate-400">
                    Min. buyurtma: {d.minOrderAmount ? `${d.minOrderAmount.toLocaleString()} UZS` : 'Cheklov yo\'q'}
                  </p>
                </div>

                <button
                  onClick={() => handleDelete(d.id)}
                  className="bg-red-50 text-red-600 p-2 rounded-lg hover:bg-red-600 hover:text-white"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
