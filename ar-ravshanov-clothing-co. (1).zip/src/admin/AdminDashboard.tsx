import React, { useEffect, useState } from 'react';
import { DollarSign, ShoppingBag, Users, Package, TrendingUp, AlertTriangle, ArrowUpRight } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, BarChart, Bar } from 'recharts';
import { fetchDashboardStats } from '../services/api';
import { DashboardStats } from '../types';

export const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardStats()
      .then(setStats)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading || !stats) {
    return <div className="p-8 text-center text-slate-400">Statistika yuklanmoqda...</div>;
  }

  const formatPrice = (price: number) => price.toLocaleString('uz-UZ') + ' UZS';

  return (
    <div className="space-y-8">
      {/* Top Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 uppercase font-sans tracking-tight">
          BOSHQARUV PANELI (DASHBOARD)
        </h1>
        <p className="text-xs text-slate-500 mt-1 font-medium">
          Saytingizdagi so'nggi savdo va buyurtmalar ko'rsatkichlari.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">JAMI TUSHUM (REVENUE)</span>
            <p className="text-xl font-black text-slate-900 font-sans">{formatPrice(stats.totalRevenue)}</p>
            <span className="text-[10px] text-emerald-600 font-bold flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" /> +18.5% o'tgan oyga nisbatan
            </span>
          </div>
          <div className="w-12 h-12 bg-amber-400/20 text-amber-600 rounded-xl flex items-center justify-center font-bold text-xl">
            💰
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">BUYURTMALAR</span>
            <p className="text-xl font-black text-slate-900 font-sans">{stats.totalOrders} ta</p>
            <span className="text-[10px] text-emerald-600 font-bold flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" /> +12 yangi buyurtma bugun
            </span>
          </div>
          <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center font-bold text-xl">
            📦
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">MIJOZLAR</span>
            <p className="text-xl font-black text-slate-900 font-sans">{stats.totalCustomers} ta</p>
            <span className="text-[10px] text-emerald-600 font-bold flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" /> Faol xaridorlar
            </span>
          </div>
          <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center font-bold text-xl">
            👥
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">MAHSULOTLAR</span>
            <p className="text-xl font-black text-slate-900 font-sans">{stats.totalProducts} ta</p>
            <span className="text-[10px] text-slate-500 font-medium">Omborda faol</span>
          </div>
          <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center font-bold text-xl">
            🛍️
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Revenue Area Chart */}
        <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider font-sans">
              OYLIK TUSHUM GRAFIGI (REVENUE STATS)
            </h3>
            <span className="text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-semibold">2026-yil</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.salesData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} tickFormatter={(v) => `${(v/1000000).toFixed(0)}M`} />
                <Tooltip formatter={(value: any) => formatPrice(value)} />
                <Area type="monotone" dataKey="revenue" stroke="#f59e0b" strokeWidth={3} fillOpacity={1} fill="url(#colorRevenue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Weekly Bar Chart */}
        <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider font-sans">
              HAFTALIK SAVDO
            </h3>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.weeklyData}>
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} tickFormatter={(v) => `${(v/1000000).toFixed(0)}M`} />
                <Tooltip formatter={(val: any) => formatPrice(val)} />
                <Bar dataKey="sales" fill="#0f172a" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Low Stock Warning & Recent Orders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Low Stock Alert */}
        {stats.lowStockProducts.length > 0 && (
          <div className="lg:col-span-4 bg-amber-50 border border-amber-200 p-5 rounded-2xl space-y-3">
            <div className="flex items-center space-x-2 text-amber-800 font-extrabold text-xs uppercase">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>KAM QOLGAN MAHSULOTLAR ({stats.lowStockProducts.length})</span>
            </div>
            <div className="space-y-2 max-h-56 overflow-y-auto">
              {stats.lowStockProducts.map((p) => (
                <div key={p.id} className="p-2.5 bg-white rounded-xl border border-amber-200/80 flex items-center justify-between text-xs">
                  <div className="truncate max-w-[70%]">
                    <p className="font-bold text-slate-900 truncate">{p.name}</p>
                    <p className="text-[10px] text-slate-400">SKU: {p.sku}</p>
                  </div>
                  <span className="font-extrabold text-amber-700 bg-amber-100 px-2 py-0.5 rounded">
                    {p.stock} ta qoldi
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recent Orders Table */}
        <div className={`bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 ${
          stats.lowStockProducts.length > 0 ? 'lg:col-span-8' : 'lg:col-span-12'
        }`}>
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider font-sans">
              ENG SO'NGGI BUYURTMALAR
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase font-bold text-[10px] border-b border-slate-200">
                <tr>
                  <th className="p-3">ID</th>
                  <th className="p-3">Mijoz</th>
                  <th className="p-3">Telefon</th>
                  <th className="p-3">Summa</th>
                  <th className="p-3">To'lov</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {stats.recentOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-50">
                    <td className="p-3 font-mono font-extrabold text-amber-600">{ord.id}</td>
                    <td className="p-3 font-bold text-slate-900">{ord.customerName}</td>
                    <td className="p-3 text-slate-600">{ord.phone}</td>
                    <td className="p-3 font-bold text-slate-900">{formatPrice(ord.total)}</td>
                    <td className="p-3 text-slate-600">{ord.paymentMethod}</td>
                    <td className="p-3">
                      <span className="bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded text-[10px]">
                        {ord.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
