import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, X, Save, Upload } from 'lucide-react';
import { Category } from '../types';
import { fetchCategories, createCategory, updateCategory, deleteCategory, uploadImage } from '../services/api';

export const AdminCategories: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [name, setName] = useState('');
  const [image, setImage] = useState('');
  const [description, setDescription] = useState('');
  const [attempted, setAttempted] = useState(false);

  const loadCategories = async () => {
    setLoading(true);
    try {
      const res = await fetchCategories();
      setCategories(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCategories();
  }, []);

  const openAdd = () => {
    setEditingCat(null);
    setName('');
    setImage('https://images.unsplash.com/photo-1516826957135-700dedea698c?w=600&q=80');
    setDescription('');
    setAttempted(false);
    setIsModalOpen(true);
  };

  const openEdit = (cat: Category) => {
    setEditingCat(cat);
    setName(cat.name);
    setImage(cat.image);
    setDescription(cat.description || '');
    setAttempted(false);
    setIsModalOpen(true);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      if (event.target?.result) {
        const rawBase64 = event.target.result as string;
        const uploadedUrl = await uploadImage(rawBase64);
        setImage(uploadedUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAttempted(true);
    if (!name.trim()) return;

    try {
      const finalImage = await uploadImage(image);
      if (editingCat) {
        await updateCategory(editingCat.id, { name, image: finalImage, description });
      } else {
        await createCategory({ name, image: finalImage, description });
      }
      setIsModalOpen(false);
      loadCategories();
    } catch (err: any) {
      alert(err.message || 'Xatolik');
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Kategoriyani o\'chirmoqchimisiz?')) {
      try {
        await deleteCategory(id);
        loadCategories();
      } catch (err: any) {
        alert(err.message || 'Xatolik');
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-black text-slate-900 uppercase font-sans tracking-tight">
            KATEGORIYALAR BOSHQARUVI
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Jami {categories.length} ta kategoriya mavjud.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="bg-amber-400 text-slate-950 font-extrabold px-4 py-2.5 rounded-xl text-xs uppercase flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Kategoriya Qo'shish</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((cat) => (
          <div key={cat.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs p-4 flex space-x-4 items-center">
            <img src={cat.image} alt="" className="w-20 h-20 object-cover rounded-xl border border-slate-200" />
            <div className="flex-1 space-y-1">
              <h3 className="font-extrabold text-slate-900 text-sm uppercase">{cat.name}</h3>
              <p className="text-[11px] text-amber-600 font-bold">{cat.productCount || 0} ta mahsulot</p>
              <p className="text-[11px] text-slate-400 line-clamp-1">{cat.description}</p>
              <div className="flex space-x-2 pt-1">
                <button onClick={() => openEdit(cat)} className="text-[11px] text-slate-700 font-bold hover:underline">
                  Tahrirlash
                </button>
                <button onClick={() => handleDelete(cat.id)} className="text-[11px] text-red-600 font-bold hover:underline">
                  O'chirish
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-2xl p-6 space-y-4">
            <div className="flex justify-between items-center border-b pb-2">
              <h3 className="font-bold text-slate-900 text-sm">
                {editingCat ? 'Kategoriyani Tahrirlash' : 'Yangi Kategoriya'}
              </h3>
              <button onClick={() => setIsModalOpen(false)}>✕</button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs" noValidate>
              <div>
                <label className="block font-bold mb-1">
                  Nomi: <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={`w-full bg-slate-50 border p-2.5 rounded-xl font-bold outline-none ${
                    attempted && !name.trim() ? 'border-red-500 bg-red-50/40 ring-1 ring-red-500' : 'border-slate-300'
                  }`}
                />
                {attempted && !name.trim() && (
                  <span className="text-[10px] text-red-600 font-bold mt-0.5 block">
                    To'ldirish shart!
                  </span>
                )}
              </div>

              <div>
                <label className="block font-bold mb-1">Rasm (URL yoki Galeriyadan):</label>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={image}
                    onChange={(e) => setImage(e.target.value)}
                    className="flex-1 bg-slate-50 border border-slate-300 p-2.5 rounded-xl outline-none"
                    placeholder="https://..."
                  />
                  <label className="bg-amber-400 text-slate-950 font-extrabold px-3 py-2.5 rounded-xl cursor-pointer flex items-center space-x-1 shrink-0">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Yuklash</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                {image && (
                  <div className="mt-2 w-16 h-16 rounded-xl overflow-hidden border border-slate-200">
                    <img src={image} alt="" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              <div>
                <label className="block font-bold mb-1">Tavsif:</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-50 border p-2.5 rounded-xl"
                />
              </div>

              <button type="submit" className="w-full bg-amber-400 text-slate-950 font-black py-3 rounded-xl uppercase">
                Saqlash
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
