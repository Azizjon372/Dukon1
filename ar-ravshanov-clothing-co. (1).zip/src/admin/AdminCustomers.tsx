import React, { useState, useEffect } from 'react';
import { User, ShieldCheck, ShieldAlert, Search } from 'lucide-react';
import { UserProfile } from '../types';
import { fetchCustomers, toggleCustomerBlock } from '../services/api';

export const AdminCustomers: React.FC = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const loadUsers = async () => {
    setLoading(true);
    try {
      const res = await fetchCustomers();
      setUsers(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleToggleBlock = async (userId: string) => {
    try {
      const updated = await toggleCustomerBlock(userId);
      setUsers((prev) => prev.map((u) => (u.id === userId ? updated : u)));
    } catch (err: any) {
      alert(err.message || 'Xatolik');
    }
  };

  const filtered = users.filter((u) =>
    u.fullName.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase()) ||
    (u.phone && u.phone.includes(search))
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-black text-slate-900 uppercase font-sans tracking-tight">
            MIJOZLAR BOSHQARUVI
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Ro'yxatdan o'tgan mijozlar bazasi ({users.length} ta mijoz).
          </p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs max-w-sm">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Mijoz ismi, Email yoki Telefon..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl py-2 pl-9 pr-3 text-xs outline-none"
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900 text-white uppercase font-bold text-[10px]">
              <tr>
                <th className="p-3.5">Mijoz ID</th>
                <th className="p-3.5">Ism / Familiya</th>
                <th className="p-3.5">Email</th>
                <th className="p-3.5">Telefon</th>
                <th className="p-3.5">Shahar</th>
                <th className="p-3.5">Roli</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Amallar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">Yuklanmoqda...</td>
                </tr>
              ) : filtered.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50">
                  <td className="p-3.5 font-mono text-slate-500">{u.id}</td>
                  <td className="p-3.5 font-extrabold text-slate-900">{u.fullName}</td>
                  <td className="p-3.5 text-slate-600">{u.email}</td>
                  <td className="p-3.5 text-slate-600">{u.phone || '—'}</td>
                  <td className="p-3.5 text-slate-600">{u.city || 'Toshkent'}</td>
                  <td className="p-3.5">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${u.role === 'admin' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'}`}>
                      {u.role.toUpperCase()}
                    </span>
                  </td>
                  <td className="p-3.5">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${u.isBlocked ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'}`}>
                      {u.isBlocked ? 'Bloklangan' : 'Faol'}
                    </span>
                  </td>
                  <td className="p-3.5 text-right">
                    {u.role !== 'admin' && (
                      <button
                        onClick={() => handleToggleBlock(u.id)}
                        className={`px-3 py-1 rounded-lg text-[10px] font-bold uppercase transition-colors ${
                          u.isBlocked ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'
                        }`}
                      >
                        {u.isBlocked ? 'Blokdan chiqarish' : 'Bloklash'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
