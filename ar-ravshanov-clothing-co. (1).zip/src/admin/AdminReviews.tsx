import React, { useState, useEffect } from 'react';
import { Star, CheckCircle, Trash2 } from 'lucide-react';
import { Review } from '../types';
import { fetchReviews, approveReview, deleteReview } from '../services/api';

export const AdminReviews: React.FC = () => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  const loadReviews = async () => {
    setLoading(true);
    try {
      const res = await fetchReviews();
      setReviews(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReviews();
  }, []);

  const handleApprove = async (id: string) => {
    try {
      const updated = await approveReview(id);
      setReviews((prev) => prev.map((r) => (r.id === id ? updated : r)));
    } catch (err: any) {
      alert(err.message || 'Xatolik');
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Izohni o\'chirmoqchimisiz?')) {
      try {
        await deleteReview(id);
        setReviews((prev) => prev.filter((r) => r.id !== id));
      } catch (err: any) {
        alert(err.message || 'Xatolik');
      }
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-slate-900 uppercase font-sans tracking-tight">
          MIJOZLAR SHARHLARI & SHARH MODERATSIYASI
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Saytda qoldirilgan barcha baho va izohlar ({reviews.length} ta).
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reviews.map((rev) => (
          <div key={rev.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-extrabold text-slate-900 text-sm">{rev.userName}</h4>
                <p className="text-[10px] text-slate-400">{new Date(rev.createdAt).toLocaleDateString('uz-UZ')}</p>
              </div>
              <div className="flex text-amber-400 text-xs">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={`w-3.5 h-3.5 ${i < rev.rating ? 'fill-amber-400' : 'text-slate-200'}`} />
                ))}
              </div>
            </div>

            <p className="text-xs text-slate-700 italic">"{rev.comment}"</p>

            <div className="flex justify-between items-center pt-2 border-t border-slate-100">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${rev.isApproved ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                {rev.isApproved ? 'Tasdiqlangan' : 'Kutilmoqda'}
              </span>

              <div className="flex space-x-2">
                {!rev.isApproved && (
                  <button
                    onClick={() => handleApprove(rev.id)}
                    className="bg-emerald-600 text-white font-bold px-3 py-1 rounded-lg text-[10px] uppercase"
                  >
                    Tasdiqlash
                  </button>
                )}
                <button
                  onClick={() => handleDelete(rev.id)}
                  className="bg-red-50 text-red-600 hover:bg-red-600 hover:text-white p-1 rounded-lg text-xs"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
