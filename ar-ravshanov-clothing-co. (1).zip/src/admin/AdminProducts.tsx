import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit2, Trash2, Eye, Star, Image, X, Save, Upload, AlertCircle } from 'lucide-react';
import { Product, Category } from '../types';
import { fetchProducts, createProduct, updateProduct, deleteProduct, fetchCategories, uploadImage } from '../services/api';

export const AdminProducts: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState('barchasi');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [oldPrice, setOldPrice] = useState('');
  const [discount, setDiscount] = useState('');
  const [category, setCategory] = useState('Kiyimlar');
  const [brand, setBrand] = useState('AR');
  const [sku, setSku] = useState('');
  const [stock, setStock] = useState('10');
  const [imageInput, setImageInput] = useState('');
  const [imageList, setImageList] = useState<string[]>([]);
  const [isFeatured, setIsFeatured] = useState(false);
  const [isBestSeller, setIsBestSeller] = useState(false);
  const [isPublished, setIsPublished] = useState(true);
  const [attempted, setAttempted] = useState(false);
  const [formError, setFormError] = useState('');

  const loadData = async () => {
    setLoading(true);
    try {
      const [pRes, cRes] = await Promise.all([
        fetchProducts({ publishedOnly: 'false', limit: 100 }),
        fetchCategories()
      ]);
      setProducts(pRes.products);
      setCategories(cRes);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openAddModal = () => {
    setEditingProduct(null);
    setName('');
    setDescription('');
    setPrice('');
    setOldPrice('');
    setDiscount('');
    setCategory(categories[0]?.name || 'Kiyimlar');
    setBrand('AR');
    setSku(`AR-${Math.floor(1000 + Math.random() * 9000)}`);
    setStock('15');
    setImageList(['https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&q=80']);
    setIsFeatured(false);
    setIsBestSeller(false);
    setIsPublished(true);
    setAttempted(false);
    setFormError('');
    setIsModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setName(p.name);
    setDescription(p.description);
    setPrice(p.price.toString());
    setOldPrice(p.oldPrice ? p.oldPrice.toString() : '');
    setDiscount(p.discount ? p.discount.toString() : '');
    setCategory(p.category);
    setBrand(p.brand);
    setSku(p.sku);
    setStock(p.stock.toString());
    setImageList(p.images || []);
    setIsFeatured(Boolean(p.isFeatured));
    setIsBestSeller(Boolean(p.isBestSeller));
    setIsPublished(p.isPublished !== false);
    setAttempted(false);
    setFormError('');
    setIsModalOpen(true);
  };

  const handleAddImage = () => {
    if (imageInput.trim()) {
      setImageList((prev) => [...prev, imageInput.trim()]);
      setImageInput('');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = async (event) => {
        if (event.target?.result) {
          const rawBase64 = event.target.result as string;
          const uploadedUrl = await uploadImage(rawBase64);
          setImageList((prev) => [...prev, uploadedUrl]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoveImage = (idx: number) => {
    setImageList((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAttempted(true);
    setFormError('');

    if (!name.trim() || !price || !category) {
      setFormError('To\'ldirish shart! Iltimos, barcha majburiy (qizil) maydonlarni to\'ldiring.');
      return;
    }

    try {
      const uploadedImages = await Promise.all(imageList.map((img) => uploadImage(img)));
      const finalImages = uploadedImages.length > 0 ? uploadedImages : ['https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&q=80'];

      const payload = {
        name: name.trim(),
        description: description.trim(),
        price: Number(price),
        oldPrice: oldPrice ? Number(oldPrice) : undefined,
        discount: discount ? Number(discount) : undefined,
        category,
        brand,
        sku,
        stock: Number(stock),
        images: finalImages,
        isFeatured,
        isBestSeller,
        isPublished
      };

      if (editingProduct) {
        await updateProduct(editingProduct.id, payload);
      } else {
        await createProduct(payload);
      }
      setIsModalOpen(false);
      loadData();
    } catch (err: any) {
      setFormError(err.message || 'Saqlashda xatolik');
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Rostdan ham ushbu mahsulotni o\'chirmoqchimisiz?')) {
      try {
        await deleteProduct(id);
        loadData();
      } catch (err: any) {
        alert(err.message || 'O\'chirishda xatolik');
      }
    }
  };

  const formatPrice = (price: number) => price.toLocaleString('uz-UZ') + ' UZS';

  const filteredProducts = products.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.sku.toLowerCase().includes(search.toLowerCase());
    const matchCat = selectedCat === 'barchasi' || p.category.toLowerCase() === selectedCat.toLowerCase();
    return matchSearch && matchCat;
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 uppercase font-sans tracking-tight">
            MAHSULOTLAR BOSHQARUVI
          </h1>
          <p className="text-xs text-slate-500 mt-1 font-medium">
            Jami {products.length} ta mahsulot mavjud.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="bg-amber-400 text-slate-950 hover:bg-amber-300 font-extrabold px-5 py-3 rounded-xl text-xs uppercase tracking-wider shadow-md flex items-center space-x-2 transition-transform hover:scale-105"
          id="add-product-admin-btn"
        >
          <Plus className="w-4 h-4" />
          <span>YANGI MAHSULOT QO'SHISH</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Nomi yoki SKU bo'yicha..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl py-2 pl-9 pr-3 text-xs outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <span className="text-xs font-bold text-slate-500">Kategoriya:</span>
          <select
            value={selectedCat}
            onChange={(e) => setSelectedCat(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800 outline-none"
          >
            <option value="barchasi">Barchasi</option>
            {categories.map((c) => (
              <option key={c.id} value={c.name}>{c.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900 text-white uppercase font-bold text-[10px]">
              <tr>
                <th className="p-3.5">Rasm</th>
                <th className="p-3.5">Nomi</th>
                <th className="p-3.5">SKU</th>
                <th className="p-3.5">Kategoriya</th>
                <th className="p-3.5">Narxi</th>
                <th className="p-3.5">Zaxira (Stock)</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Amallar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">Yuklanmoqda...</td>
                </tr>
              ) : filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">Mahsulot topilmadi</td>
                </tr>
              ) : (
                filteredProducts.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-3.5">
                      <img src={p.images[0]} alt="" className="w-10 h-12 object-cover rounded-lg border border-slate-200" />
                    </td>
                    <td className="p-3.5 font-extrabold text-slate-900">
                      {p.name}
                      {p.isFeatured && <span className="ml-2 text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-bold uppercase">Featured</span>}
                    </td>
                    <td className="p-3.5 font-mono text-slate-500 font-bold">{p.sku}</td>
                    <td className="p-3.5 text-slate-700 font-semibold">{p.category}</td>
                    <td className="p-3.5 font-black text-slate-900">{formatPrice(p.price)}</td>
                    <td className="p-3.5 font-bold">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${p.stock <= 5 ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'}`}>
                        {p.stock} ta
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${p.isPublished ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'}`}>
                        {p.isPublished ? 'Chop etilgan' : 'Yashiringan'}
                      </span>
                    </td>
                    <td className="p-3.5 text-right space-x-2">
                      <button
                        onClick={() => openEditModal(p)}
                        className="p-1.5 bg-slate-100 text-slate-700 hover:bg-slate-900 hover:text-white rounded-lg transition-colors"
                        title="Tahrirlash"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(p.id)}
                        className="p-1.5 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white rounded-lg transition-colors"
                        title="O'chirish"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit Product */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl p-6 border border-slate-200 my-8 space-y-5 animate-in fade-in max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-slate-900 text-base uppercase font-sans">
                {editingProduct ? 'MAHSULOTNI TAHRIRLASH' : 'YANGI MAHSULOT QO\'SHISH'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-900">
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-red-50 border border-red-300 text-red-700 rounded-xl text-xs font-bold flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Mahsulot Nomi: <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={`w-full bg-slate-50 border rounded-xl p-2.5 text-xs outline-none focus:border-amber-500 font-bold ${
                      attempted && !name.trim() ? 'border-red-500 bg-red-50/40 ring-1 ring-red-500' : 'border-slate-300'
                    }`}
                  />
                  {attempted && !name.trim() && (
                    <span className="text-[10px] text-red-600 font-bold mt-0.5 block">
                      To'ldirish shart!
                    </span>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    SKU Kodi:
                  </label>
                  <input
                    type="text"
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-mono outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Sotuv Narxi (UZS): <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className={`w-full bg-slate-50 border rounded-xl p-2.5 text-xs outline-none focus:border-amber-500 font-bold ${
                      attempted && !price ? 'border-red-500 bg-red-50/40 ring-1 ring-red-500' : 'border-slate-300'
                    }`}
                  />
                  {attempted && !price && (
                    <span className="text-[10px] text-red-600 font-bold mt-0.5 block">
                      To'ldirish shart!
                    </span>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Eski Narxi (Eski):
                  </label>
                  <input
                    type="number"
                    value={oldPrice}
                    onChange={(e) => setOldPrice(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Chegirma %:
                  </label>
                  <input
                    type="number"
                    value={discount}
                    onChange={(e) => setDiscount(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Kategoriya:
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-semibold"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Brand:
                  </label>
                  <input
                    type="text"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Ombor Soni (Stock):
                  </label>
                  <input
                    type="number"
                    value={stock}
                    onChange={(e) => setStock(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Tavsif (Description):
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs outline-none h-20"
                />
              </div>

              {/* Image list & Upload */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Mahsulot rasmlari (URL va Galeriyadan yuklash):
                </label>
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <input
                    type="text"
                    placeholder="https://images.unsplash.com/..."
                    value={imageInput}
                    onChange={(e) => setImageInput(e.target.value)}
                    className="flex-1 min-w-[200px] bg-slate-50 border border-slate-300 rounded-xl p-2 text-xs outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleAddImage}
                    className="bg-slate-900 text-white font-bold px-4 py-2 rounded-xl text-xs"
                  >
                    URL Qo'shish
                  </button>
                  <label className="bg-amber-400 text-slate-950 hover:bg-amber-300 font-extrabold px-4 py-2 rounded-xl text-xs cursor-pointer flex items-center space-x-1.5 shadow-xs transition-transform active:scale-95">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Galeriyadan yuklash</span>
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                <div className="flex space-x-2 overflow-x-auto py-1">
                  {imageList.map((url, idx) => (
                    <div key={idx} className="relative w-16 h-16 rounded-lg overflow-hidden border shrink-0 group">
                      <img src={url} alt="" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(idx)}
                        className="absolute inset-0 bg-red-600/80 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity font-bold text-xs"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Toggles */}
              <div className="flex flex-wrap gap-4 pt-2 border-t border-slate-100 text-xs font-bold">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isFeatured}
                    onChange={(e) => setIsFeatured(e.target.checked)}
                    className="rounded text-amber-500"
                  />
                  <span>Featured Product (Bosh sahifa)</span>
                </label>

                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isBestSeller}
                    onChange={(e) => setIsBestSeller(e.target.checked)}
                    className="rounded text-amber-500"
                  />
                  <span>Best Seller (Eng sotilgan)</span>
                </label>

                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isPublished}
                    onChange={(e) => setIsPublished(e.target.checked)}
                    className="rounded text-amber-500"
                  />
                  <span>Chop etilgan (Published)</span>
                </label>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-700"
                >
                  Bekor qilish
                </button>
                <button
                  type="submit"
                  className="bg-amber-400 text-slate-950 hover:bg-amber-300 font-extrabold px-6 py-2.5 rounded-xl text-xs uppercase tracking-wider flex items-center space-x-2"
                >
                  <Save className="w-4 h-4" />
                  <span>SAQLASH</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
