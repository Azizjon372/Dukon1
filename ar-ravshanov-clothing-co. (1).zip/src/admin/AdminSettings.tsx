import React, { useState, useEffect } from 'react';
import { Settings, Save, CheckCircle } from 'lucide-react';
import { SiteSettings } from '../types';
import { fetchSiteSettings, updateSiteSettings } from '../services/api';

export const AdminSettings: React.FC = () => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetchSiteSettings()
      .then(setSettings)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;

    try {
      await updateSiteSettings(settings);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err: any) {
      alert(err.message || 'Xatolik');
    }
  };

  if (loading || !settings) {
    return <div className="p-8 text-center text-slate-400">Sozlamalar yuklanmoqda...</div>;
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-black text-slate-900 uppercase font-sans tracking-tight">
          SAYT SOZLAMALARI (SITE SETTINGS)
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Kompaniya brendi, telefon raqamlari va banner matnlarini boshqaring.
        </p>
      </div>

      {saved && (
        <div className="p-4 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl flex items-center space-x-2">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          <span>Sozlamalar muvaffaqiyatli saqlandi!</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 uppercase mb-1">Kompaniya Nomi:</label>
            <input
              type="text"
              value={settings.siteName}
              onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
              className="w-full bg-slate-50 border p-2.5 rounded-xl font-bold"
              required
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase mb-1">Dasturchi (Developer):</label>
            <input
              type="text"
              value={settings.developer}
              onChange={(e) => setSettings({ ...settings, developer: e.target.value })}
              className="w-full bg-slate-50 border p-2.5 rounded-xl font-bold text-amber-600"
              required
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase mb-1">Mijozlar Telefoni:</label>
            <input
              type="text"
              value={settings.phone}
              onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
              className="w-full bg-slate-50 border p-2.5 rounded-xl font-bold"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase mb-1">Email:</label>
            <input
              type="email"
              value={settings.email}
              onChange={(e) => setSettings({ ...settings, email: e.target.value })}
              className="w-full bg-slate-50 border p-2.5 rounded-xl font-bold"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase mb-1">Telegram Havola:</label>
            <input
              type="text"
              value={settings.telegram}
              onChange={(e) => setSettings({ ...settings, telegram: e.target.value })}
              className="w-full bg-slate-50 border p-2.5 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase mb-1">Free Shipping Min Summa (UZS):</label>
            <input
              type="number"
              value={settings.freeDeliveryMinAmount}
              onChange={(e) => setSettings({ ...settings, freeDeliveryMinAmount: Number(e.target.value) })}
              className="w-full bg-slate-50 border p-2.5 rounded-xl font-bold"
            />
          </div>
        </div>

        <div className="space-y-3 text-xs border-t pt-4">
          <h4 className="font-extrabold text-slate-900 uppercase">HERO BANNER SOZLAMALARI</h4>

          <div>
            <label className="block font-bold text-slate-700 uppercase mb-1">Banner Sarlavhasi (Hero Title):</label>
            <input
              type="text"
              value={settings.heroTitle}
              onChange={(e) => setSettings({ ...settings, heroTitle: e.target.value })}
              className="w-full bg-slate-50 border p-2.5 rounded-xl font-bold text-sm"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase mb-1">Banner Kichik Matni (Subtitle):</label>
            <textarea
              value={settings.heroSubtitle}
              onChange={(e) => setSettings({ ...settings, heroSubtitle: e.target.value })}
              className="w-full bg-slate-50 border p-2.5 rounded-xl h-20"
            />
          </div>
        </div>

        <button
          type="submit"
          className="bg-amber-400 text-slate-950 font-black px-8 py-3 rounded-xl text-xs uppercase flex items-center space-x-2"
        >
          <Save className="w-4 h-4" />
          <span>SOZLAMALARNI SAQLASH</span>
        </button>
      </form>
    </div>
  );
};
