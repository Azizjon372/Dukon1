export interface Product {
  id: string;
  name: string;
  description: string;
  price: number; // in UZS
  oldPrice?: number;
  discount?: number; // percentage e.g. 15
  category: string;
  brand: string;
  sku: string;
  stock: number;
  rating: number;
  numReviews: number;
  images: string[];
  specifications: Record<string, string>;
  isFeatured?: boolean;
  isBestSeller?: boolean;
  isPublished: boolean;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  image: string;
  productCount?: number;
  description?: string;
}

export interface OrderItem {
  id: string;
  productId: string;
  name: string;
  image: string;
  price: number;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

export type OrderStatus = 'Yangi' | 'Tasdiqlangan' | 'Tayyorlanmoqda' | 'Yuborildi' | 'Yetkazildi' | 'Bekor qilindi';

export interface Order {
  id: string;
  userId?: string;
  customerName: string;
  phone: string;
  city: string;
  address: string;
  notes?: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  discountAmount: number;
  promoCode?: string;
  total: number;
  paymentMethod: 'Click' | 'Payme' | 'Uzcard/Humo' | 'Naqd';
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  role: 'admin' | 'customer';
  isBlocked?: boolean;
  city?: string;
  address?: string;
  createdAt: string;
}

export interface Review {
  id: string;
  productId: string;
  productName?: string;
  userName: string;
  rating: number;
  comment: string;
  isApproved: boolean;
  createdAt: string;
}

export interface DiscountCode {
  id: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number; // e.g. 10 for 10% or 50000 for 50k UZS
  minOrderAmount?: number;
  startDate: string;
  endDate: string;
  isActive: boolean;
  usageCount: number;
}

export interface SiteSettings {
  companyName: string;
  logoText: string;
  logoSubtext: string;
  phone: string;
  email: string;
  address: string;
  telegram: string;
  instagram: string;
  heroBadge: string;
  heroHeadline: string;
  heroSubheadline: string;
  heroCtaText: string;
  heroImage: string;
  freeShippingMinAmount: number;
  standardDeliveryFee: number;
  footerInfo: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export interface DashboardStats {
  totalRevenue: number;
  totalOrders: number;
  totalCustomers: number;
  totalProducts: number;
  salesData: { name: string; revenue: number; orders: number }[];
  weeklyData: { day: string; sales: number }[];
  recentOrders: Order[];
  bestSellers: Product[];
  lowStockProducts: Product[];
}
