import React, { useState } from 'react';
import { Search, ShoppingBag, Heart, User, Menu, X, ShieldAlert, Phone } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenAuth: () => void;
  onSearchSubmit: (query: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  onOpenAuth,
  onSearchSubmit
}) => {
  const { totalItemsCount, wishlist, setIsCartOpen } = useCart();
  const { user, isAdmin, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearchSubmit(searchQuery.trim());
      setCurrentTab('products');
    }
  };

  const navItems = [
    { id: 'home', label: 'BOSH SAHIFA' },
    { id: 'new-arrivals', label: 'YANGI KELGANLAR' },
    { id: 'clothing', label: 'KIYIMLAR' },
    { id: 'accessories', label: 'AKSESSUARLAR' },
    { id: 'brands', label: 'BRENDLAR' },
    { id: 'sale', label: 'CHEGIRMALAR' },
    { id: 'about', label: 'HAQIMIZDA' },
    { id: 'contact', label: 'BOG\'LANISH' }
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      {/* Top Banner Bar */}
      <div className="bg-slate-900 text-slate-300 text-xs py-2 px-4 sm:px-8 flex justify-between items-center border-b border-slate-800">
        <div className="flex items-center space-x-6">
          <span className="flex items-center space-x-1 font-medium text-slate-200">
            <Phone className="w-3.5 h-3.5 text-amber-400" />
            <span>+998 90 123 45 67</span>
          </span>
          <span className="hidden md:inline-block text-slate-400">
            Bepul yetkazib berish (500,000 UZS dan yuqori xaridlarga)
          </span>
        </div>
        <div className="flex items-center space-x-4">
          <span className="hidden sm:inline-block text-amber-400 font-semibold text-[11px] tracking-wider uppercase">
            Dasturchi: Aziz Ravshanov
          </span>
          <button
            onClick={() => setCurrentTab('admin')}
            className="flex items-center space-x-1 bg-amber-400/10 text-amber-400 hover:bg-amber-400 hover:text-slate-950 px-2.5 py-0.5 rounded text-[11px] font-bold transition-all border border-amber-400/30"
            id="admin-panel-nav-btn"
          >
            <ShieldAlert className="w-3 h-3" />
            <span>ADMIN PANEL</span>
          </button>
        </div>
      </div>

      {/* Main Logo & Search Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-4 flex items-center justify-between gap-4">
        {/* Brand Logo - Editorial Style */}
        <button
          onClick={() => setCurrentTab('home')}
          className="flex items-center space-x-3 group text-left"
          id="brand-logo-btn"
        >
          <div className="w-10 h-10 bg-slate-900 text-white rounded-full flex items-center justify-center font-bold text-sm tracking-tight border border-slate-800 shadow-xs group-hover:bg-amber-400 group-hover:text-slate-950 transition-colors">
            AR
          </div>
          <div className="flex flex-col">
            <span className="font-serif italic font-bold text-lg sm:text-2xl tracking-tight text-slate-900 leading-none">
              AR Store
            </span>
            <span className="text-[9px] sm:text-[10px] tracking-[0.25em] text-slate-400 font-semibold uppercase leading-tight mt-0.5">
              EDITORIAL CLOTHING
            </span>
          </div>
        </button>

        {/* Center Search Input - Editorial Pill */}
        <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-md mx-6">
          <div className="relative w-full">
            <input
              type="text"
              placeholder="Qidirish..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-100 border border-slate-200/80 focus:border-slate-900 focus:bg-white rounded-full py-2 pl-4 pr-10 text-xs text-slate-800 placeholder-slate-400 outline-none transition-all"
              id="search-input-header"
            />
            <button
              type="submit"
              className="absolute right-1 top-1/2 -translate-y-1/2 w-7 h-7 bg-slate-900 text-white rounded-full flex items-center justify-center hover:bg-amber-500 transition-colors"
              id="search-submit-btn"
            >
              <Search className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>

        {/* Right Actions: User, Wishlist, Cart */}
        <div className="flex items-center space-x-3 sm:space-x-5">
          {/* User Profile / Auth */}
          <div className="relative">
            {user ? (
              <div>
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center space-x-2 text-slate-800 hover:text-amber-600 font-medium text-xs sm:text-sm py-1.5 px-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors"
                  id="user-menu-btn"
                >
                  <div className="w-6 h-6 bg-amber-400 text-slate-950 rounded-full font-bold text-xs flex items-center justify-center">
                    {user.fullName.charAt(0).toUpperCase()}
                  </div>
                  <span className="hidden sm:inline-block max-w-[100px] truncate">{user.fullName}</span>
                </button>

                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white border border-slate-200 rounded-xl shadow-lg py-2 z-50">
                    <div className="px-4 py-2 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-900">{user.fullName}</p>
                      <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                    </div>
                    {isAdmin && (
                      <button
                        onClick={() => {
                          setUserDropdownOpen(false);
                          setCurrentTab('admin');
                        }}
                        className="w-full text-left px-4 py-2 text-xs font-semibold text-amber-600 hover:bg-amber-50 flex items-center space-x-2"
                      >
                        <ShieldAlert className="w-3.5 h-3.5" />
                        <span>Admin Boshqaruvi</span>
                      </button>
                    )}
                    <button
                      onClick={() => {
                        setUserDropdownOpen(false);
                        setCurrentTab('account');
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50"
                    >
                      Mening Profilim
                    </button>
                    <button
                      onClick={() => {
                        setUserDropdownOpen(false);
                        setCurrentTab('account');
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50"
                    >
                      Buyurtmalarim
                    </button>
                    <button
                      onClick={() => {
                        setUserDropdownOpen(false);
                        logout();
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-red-600 hover:bg-red-50 border-t border-slate-100"
                    >
                      Chiqish (Logout)
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center space-x-1.5 bg-slate-900 text-white hover:bg-amber-500 hover:text-slate-950 px-3.5 py-2 rounded-lg text-xs font-bold tracking-wider uppercase transition-all shadow-xs"
                id="login-register-nav-btn"
              >
                <User className="w-3.5 h-3.5" />
                <span>KIRISH</span>
              </button>
            )}
          </div>

          {/* Wishlist Button */}
          <button
            onClick={() => setCurrentTab('products')}
            className="relative p-2 text-slate-700 hover:text-red-500 transition-colors"
            title="Saralanganlar"
            id="wishlist-header-btn"
          >
            <Heart className="w-5 h-5" />
            {wishlist.length > 0 && (
              <span className="absolute top-0 right-0 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* Cart Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative flex items-center space-x-1.5 bg-slate-900 hover:bg-slate-800 text-white px-3 py-2 rounded-lg transition-all shadow-sm"
            id="cart-drawer-trigger-btn"
          >
            <ShoppingBag className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold bg-amber-400 text-slate-950 px-1.5 py-0.5 rounded-full">
              {totalItemsCount}
            </span>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-slate-700 hover:text-slate-900"
            id="mobile-menu-toggle-btn"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Main Navigation Link Bar */}
      <nav className="bg-slate-900 text-white border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 flex items-center justify-between overflow-x-auto scrollbar-none py-2.5">
          <div className="flex items-center space-x-1 sm:space-x-4 min-w-max">
            {navItems.map((item) => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`px-3 py-1.5 text-xs font-bold tracking-wider transition-all rounded ${
                    isActive
                      ? 'bg-amber-400 text-slate-950 shadow-xs'
                      : 'text-slate-300 hover:text-amber-400 hover:bg-slate-800/80'
                  }`}
                  id={`nav-link-${item.id}`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 px-4 py-4 space-y-3">
          <form onSubmit={handleSearch} className="flex">
            <input
              type="text"
              placeholder="Qidirish..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-100 border border-slate-300 rounded-l-lg py-2 px-3 text-xs outline-none"
            />
            <button
              type="submit"
              className="bg-slate-900 text-white px-4 rounded-r-lg font-semibold text-xs"
            >
              Qidirish
            </button>
          </form>

          <div className="grid grid-cols-2 gap-2 pt-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className="text-left py-2 px-3 text-xs font-semibold text-slate-800 bg-slate-50 rounded-lg hover:bg-amber-50 hover:text-amber-600"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};
