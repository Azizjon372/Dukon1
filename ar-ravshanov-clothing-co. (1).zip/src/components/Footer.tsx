import React from 'react';
import { Phone, Mail, MapPin, Send, Instagram, ShieldCheck, Heart } from 'lucide-react';

interface FooterProps {
  setCurrentTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentTab }) => {
  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand Info Column */}
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-amber-400 text-slate-950 font-black text-xl rounded-lg flex items-center justify-center">
              AR
            </div>
            <div>
              <p className="font-extrabold text-white text-base tracking-wider uppercase">RAVSHANOV</p>
              <p className="text-[10px] tracking-[0.2em] text-amber-400 uppercase font-semibold">CLOTHING CO.</p>
            </div>
          </div>
          <p className="text-slate-400 text-xs leading-relaxed">
            O'zbekistondagi premium sifatli erkaklar va ayollar kiyim-kechak brendi. Zamonaviy dizayn va qulaylik uyg'unligi.
          </p>
          <div className="flex space-x-3 pt-1">
            <a href="https://t.me/azizravshanov" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-lg bg-slate-900 hover:bg-amber-400 hover:text-slate-950 flex items-center justify-center transition-colors">
              <Send className="w-4 h-4" />
            </a>
            <a href="https://instagram.com/ravshanov_clothing" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-lg bg-slate-900 hover:bg-amber-400 hover:text-slate-950 flex items-center justify-center transition-colors">
              <Instagram className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Catalog Navigation */}
        <div className="space-y-3">
          <h4 className="font-extrabold text-white uppercase text-xs tracking-wider font-sans border-b border-slate-800 pb-2">
            KATALOG
          </h4>
          <ul className="space-y-2">
            <li><button onClick={() => setCurrentTab('clothing')} className="hover:text-amber-400 transition-colors">Kiyimlar (Kurtkalar, Xudi)</button></li>
            <li><button onClick={() => setCurrentTab('accessories')} className="hover:text-amber-400 transition-colors">Aksessuarlar (Soat, Kamar)</button></li>
            <li><button onClick={() => setCurrentTab('new-arrivals')} className="hover:text-amber-400 transition-colors">Yangi Kelganlar</button></li>
            <li><button onClick={() => setCurrentTab('sale')} className="hover:text-amber-400 transition-colors">Chegirmali Mahsulotlar</button></li>
            <li><button onClick={() => setCurrentTab('products')} className="hover:text-amber-400 transition-colors">Barcha Mahsulotlar</button></li>
          </ul>
        </div>

        {/* Customer Care */}
        <div className="space-y-3">
          <h4 className="font-extrabold text-white uppercase text-xs tracking-wider font-sans border-b border-slate-800 pb-2">
            MIJOZLARGA YORDAM
          </h4>
          <ul className="space-y-2">
            <li><button onClick={() => setCurrentTab('about')} className="hover:text-amber-400 transition-colors">Biz Haqimizda</button></li>
            <li><button onClick={() => setCurrentTab('contact')} className="hover:text-amber-400 transition-colors">Aloqa va Manzil</button></li>
            <li><button onClick={() => setCurrentTab('account')} className="hover:text-amber-400 transition-colors">Buyurtmani Kuzatish</button></li>
            <li><span className="text-slate-500">Yetkazib berish shartlari</span></li>
            <li><span className="text-slate-500">To'lov usullari (Click, Payme, Naqd)</span></li>
          </ul>
        </div>

        {/* Contact Info */}
        <div className="space-y-3">
          <h4 className="font-extrabold text-white uppercase text-xs tracking-wider font-sans border-b border-slate-800 pb-2">
            BOG'LANISH
          </h4>
          <ul className="space-y-2.5 text-xs">
            <li className="flex items-center space-x-2">
              <Phone className="w-4 h-4 text-amber-400 shrink-0" />
              <span>+998 90 123 45 67</span>
            </li>
            <li className="flex items-center space-x-2">
              <Mail className="w-4 h-4 text-amber-400 shrink-0" />
              <span>info@ravshanov.uz</span>
            </li>
            <li className="flex items-start space-x-2">
              <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>Toshkent sh., Amir Temur ko'chasi, 108-uy</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Developer Footer Bar */}
      <div className="bg-slate-900 border-t border-slate-800 py-4 px-4 sm:px-8 text-center text-[11px] text-slate-400 flex flex-col sm:flex-row justify-between items-center max-w-7xl mx-auto gap-2">
        <p>© 2026 AR Ravshanov Clothing Co. Barcha huquqlar himoyalangan.</p>
        <p className="flex items-center space-x-1 font-semibold text-slate-300">
          <span>Dasturchi:</span>
          <strong className="text-amber-400 font-extrabold">Aziz Ravshanov</strong>
          <span>— Full-Stack E-Commerce Platform</span>
        </p>
      </div>
    </footer>
  );
};
