import React, { useState, useEffect } from 'react';
import { X, Star, ShoppingBag, Truck, ShieldCheck, Heart, Send } from 'lucide-react';
import { Product, Review } from '../types';
import { useCart } from '../context/CartContext';
import { fetchReviews, createReview } from '../services/api';

interface ProductDetailsModalProps {
  product: Product | null;
  onClose: () => void;
  onBuyNow: (product: Product, qty: number, size: string, color: string) => void;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  onClose,
  onBuyNow
}) => {
  const { addToCart, toggleWishlist, isInWishlist } = useCart();
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState('L');
  const [selectedColor, setSelectedColor] = useState('Qora');
  const [reviews, setReviews] = useState<Review[]>([]);
  const [newReviewer, setNewReviewer] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [reviewSuccessMsg, setReviewSuccessMsg] = useState('');

  useEffect(() => {
    if (product) {
      setSelectedImage(product.images[0] || '');
      setQuantity(1);
      // Load product reviews
      fetchReviews(product.id)
        .then(setReviews)
        .catch(console.error);
    }
  }, [product]);

  if (!product) return null;

  const isWished = isInWishlist(product.id);

  const formatPrice = (price: number) => {
    return price.toLocaleString('uz-UZ') + ' UZS';
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewer.trim() || !newComment.trim()) return;
    setIsSubmittingReview(true);
    try {
      const added = await createReview({
        productId: product.id,
        userName: newReviewer.trim(),
        rating: newRating,
        comment: newComment.trim()
      });
      setReviews((prev) => [added, ...prev]);
      setNewReviewer('');
      setNewComment('');
      setReviewSuccessMsg('Sharhingiz muvaffaqiyatli qabul qilindi!');
      setTimeout(() => setReviewSuccessMsg(''), 4000);
    } catch (err: any) {
      alert(err.message || 'Sharh qoldirishda xatolik');
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const sizes = ['S', 'M', 'L', 'XL', 'XXL'];
  const colors = ['Qora', 'To\'q Ko\'k', 'Kulrang', 'Jigarrang'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 relative my-8 animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 bg-slate-100 text-slate-600 hover:bg-slate-900 hover:text-white rounded-full flex items-center justify-center transition-colors shadow-xs"
          id="close-modal-btn"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="overflow-y-auto p-6 space-y-8">
          {/* Main Product Info Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Gallery Left */}
            <div className="space-y-4">
              <div className="aspect-3/4 bg-slate-100 rounded-xl overflow-hidden border border-slate-200 relative group">
                <img
                  src={selectedImage || product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={() => toggleWishlist(product)}
                  className={`absolute top-3 right-3 w-10 h-10 rounded-full flex items-center justify-center shadow-md transition-all ${
                    isWished ? 'bg-red-500 text-white' : 'bg-white/90 text-slate-700 hover:bg-white'
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isWished ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Thumbnails */}
              {product.images.length > 1 && (
                <div className="flex space-x-3 overflow-x-auto pb-2">
                  {product.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImage(img)}
                      className={`w-16 h-16 rounded-lg overflow-hidden border-2 shrink-0 ${
                        selectedImage === img ? 'border-amber-400 scale-95' : 'border-slate-200 opacity-70'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Details Right */}
            <div className="space-y-5">
              <div>
                <div className="flex items-center space-x-2 text-xs font-bold text-amber-500 uppercase tracking-widest mb-1">
                  <span>BRAND: {product.brand}</span>
                  <span>•</span>
                  <span>SKU: {product.sku}</span>
                </div>
                <h1 className="text-2xl font-black text-slate-900 uppercase font-sans tracking-wide leading-tight">
                  {product.name}
                </h1>

                <div className="flex items-center space-x-4 mt-2">
                  <div className="flex items-center space-x-1 text-amber-500 text-sm font-bold bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200">
                    <Star className="w-4 h-4 fill-current" />
                    <span>{product.rating.toFixed(1)} ({product.numReviews} sharhlar)</span>
                  </div>
                  <span className={`text-xs font-bold px-2.5 py-1 rounded-md ${
                    product.stock > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {product.stock > 0 ? `Omborda bor (${product.stock} ta)` : 'Tugagan'}
                  </span>
                </div>
              </div>

              {/* Price Box */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-2xl font-black text-slate-900">{formatPrice(product.price)}</span>
                  {product.oldPrice && (
                    <span className="ml-3 text-sm text-slate-400 line-through">
                      {formatPrice(product.oldPrice)}
                    </span>
                  )}
                </div>
                {product.discount && (
                  <span className="bg-red-600 text-white font-extrabold text-xs px-2.5 py-1 rounded-md uppercase">
                    -{product.discount}% Chegirma
                  </span>
                )}
              </div>

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
                {product.description}
              </p>

              {/* Size Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  O'lcham (Size):
                </label>
                <div className="flex space-x-2">
                  {sizes.map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setSelectedSize(sz)}
                      className={`w-10 h-10 rounded-lg text-xs font-bold border transition-all ${
                        selectedSize === sz
                          ? 'bg-slate-900 text-amber-400 border-slate-900 shadow-sm'
                          : 'bg-white text-slate-700 border-slate-300 hover:border-slate-500'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Rang:
                </label>
                <div className="flex flex-wrap gap-2">
                  {colors.map((col) => (
                    <button
                      key={col}
                      onClick={() => setSelectedColor(col)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                        selectedColor === col
                          ? 'bg-amber-400 text-slate-950 border-amber-500 font-bold'
                          : 'bg-white text-slate-700 border-slate-300'
                      }`}
                    >
                      {col}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity Selector */}
              <div className="flex items-center space-x-4">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Soni:</span>
                <div className="flex items-center border border-slate-300 rounded-lg bg-slate-50">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-9 h-9 flex items-center justify-center text-slate-700 font-bold hover:bg-slate-200 rounded-l-lg"
                  >
                    -
                  </button>
                  <span className="w-10 text-center font-bold text-sm text-slate-900">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-9 h-9 flex items-center justify-center text-slate-700 font-bold hover:bg-slate-200 rounded-r-lg"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={() => {
                    addToCart(product, quantity, selectedSize, selectedColor);
                    onClose();
                  }}
                  className="w-full bg-slate-900 text-white hover:bg-slate-800 font-extrabold py-3 rounded-xl text-xs uppercase tracking-wider flex items-center justify-center space-x-2 transition-all shadow-md"
                  id="modal-add-to-cart-btn"
                >
                  <ShoppingBag className="w-4 h-4 text-amber-400" />
                  <span>SAVATCHAGA QO'SHISH</span>
                </button>
                <button
                  onClick={() => {
                    onBuyNow(product, quantity, selectedSize, selectedColor);
                  }}
                  className="w-full bg-amber-400 text-slate-950 hover:bg-amber-300 font-extrabold py-3 rounded-xl text-xs uppercase tracking-wider transition-all shadow-md"
                  id="modal-buy-now-btn"
                >
                  HOZIRNING O'ZIDA SOTIB OLISH
                </button>
              </div>

              {/* Guarantees */}
              <div className="grid grid-cols-2 gap-3 text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                <div className="flex items-center space-x-2">
                  <Truck className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>24 soatda Bepul yetkazib berish</span>
                </div>
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>100% Asl brend kafolati</span>
                </div>
              </div>
            </div>
          </div>

          {/* Specifications Table */}
          {product.specifications && Object.keys(product.specifications).length > 0 && (
            <div className="pt-6 border-t border-slate-200">
              <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider mb-4 font-sans">
                Xarakteristikalar (Specifications)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                {Object.entries(product.specifications).map(([key, val]) => (
                  <div key={key} className="flex justify-between border-b border-slate-200/60 pb-1.5">
                    <span className="font-semibold text-slate-500">{key}:</span>
                    <span className="font-bold text-slate-800">{val}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Customer Reviews Section */}
          <div className="pt-6 border-t border-slate-200 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider font-sans">
                Mijozlar Sharhlari ({reviews.length})
              </h3>
            </div>

            {/* Submit Review Form */}
            <form onSubmit={handleReviewSubmit} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <h4 className="text-xs font-bold text-slate-800 uppercase">Sharh qoldiring:</h4>
              {reviewSuccessMsg && (
                <div className="p-2 bg-emerald-100 text-emerald-800 rounded text-xs font-bold">
                  {reviewSuccessMsg}
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Ismingiz"
                  value={newReviewer}
                  onChange={(e) => setNewReviewer(e.target.value)}
                  className="bg-white border border-slate-300 rounded-lg p-2 text-xs outline-none focus:border-amber-500"
                  required
                />
                <div className="flex items-center space-x-2 text-xs font-semibold">
                  <span>Baho:</span>
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setNewRating(star)}
                      className={`text-lg ${star <= newRating ? 'text-amber-500' : 'text-slate-300'}`}
                    >
                      ★
                    </button>
                  ))}
                </div>
              </div>
              <textarea
                placeholder="Mahsulot haqida o'z fikringizni yozing..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs outline-none focus:border-amber-500 h-20"
                required
              />
              <button
                type="submit"
                disabled={isSubmittingReview}
                className="bg-slate-900 text-white hover:bg-amber-400 hover:text-slate-950 font-bold px-4 py-2 rounded-lg text-xs uppercase flex items-center space-x-2 transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Yuborish</span>
              </button>
            </form>

            {/* Existing Reviews */}
            <div className="space-y-3">
              {reviews.map((rev) => (
                <div key={rev.id} className="p-3.5 bg-white rounded-xl border border-slate-200 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">{rev.userName}</span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(rev.createdAt).toLocaleDateString('uz-UZ')}
                    </span>
                  </div>
                  <div className="flex text-amber-400 text-xs">
                    {'★'.repeat(rev.rating)}
                  </div>
                  <p className="text-xs text-slate-600 leading-normal">{rev.comment}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
