import React, { useState } from 'react';
import { X, Lock, Mail, User, Phone, MapPin, ShieldAlert, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { formatUzPhone } from '../lib/utils';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { login, register } = useAuth();
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('+998 ');
  const [city, setCity] = useState('Toshkent');
  const [address, setAddress] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [attempted, setAttempted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAttempted(true);
    setError('');

    // Check validation
    if (tab === 'login') {
      if (!email.trim() || !password) {
        setError('To\'ldirish shart! Iltimos, email va parolni kiriting.');
        return;
      }
    } else {
      if (!fullName.trim() || !email.trim() || !password || !phone.trim() || !address.trim()) {
        setError('To\'ldirish shart! Iltimos, barcha qizil bilan belgilangan maydonlarni to\'liq to\'ldiring.');
        return;
      }
    }

    setIsLoading(true);

    try {
      if (tab === 'login') {
        await login(email.trim(), password);
      } else {
        await register({
          fullName: fullName.trim(),
          email: email.trim(),
          password,
          phone: phone.trim(),
          city,
          address: address.trim()
        });
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'Xatolik yuz berdi');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePhoneChange = (val: string) => {
    setPhone(formatUzPhone(val));
  };

  const handleFillAdmin = () => {
    setEmail('admin@ravshanov.uz');
    setPassword('admin123');
    setTab('login');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-200 relative animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-1 text-slate-400 hover:text-slate-800"
          id="close-auth-modal-btn"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Tab Headers */}
        <div className="flex border-b border-slate-200 bg-slate-50">
          <button
            onClick={() => {
              setTab('login');
              setError('');
              setAttempted(false);
            }}
            className={`flex-1 py-3.5 text-xs font-black uppercase tracking-wider text-center transition-all ${
              tab === 'login'
                ? 'bg-white text-slate-900 border-b-2 border-amber-400'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            TIZIMGA KIRISH
          </button>
          <button
            onClick={() => {
              setTab('register');
              setError('');
              setAttempted(false);
            }}
            className={`flex-1 py-3.5 text-xs font-black uppercase tracking-wider text-center transition-all ${
              tab === 'register'
                ? 'bg-white text-slate-900 border-b-2 border-amber-400'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            RO'YXATDAN O'TISH
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="text-center">
            <h3 className="font-extrabold text-slate-900 text-lg uppercase font-sans">
              AR RAVSHANOV SHAXSIY XONASI
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {tab === 'login' ? 'Hisobingizga kiring va xaridlaringizni kuzating' : 'Yangi hisob yarating yoki mavjud hisobingizga kiring'}
            </p>
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-300 text-red-700 rounded-xl text-xs font-bold flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3" noValidate>
            {tab === 'register' && (
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Ism va Familiya: <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Aziz Ravshanov"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className={`w-full bg-slate-50 border rounded-xl py-2.5 pl-9 pr-3 text-xs outline-none focus:border-amber-500 ${
                      attempted && !fullName.trim() ? 'border-red-500 bg-red-50/40 ring-1 ring-red-500' : 'border-slate-300'
                    }`}
                  />
                </div>
                {attempted && !fullName.trim() && (
                  <span className="text-[10px] text-red-600 font-bold mt-0.5 block">
                    To'ldirish shart!
                  </span>
                )}
              </div>
            )}

            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                Email Manzilingiz: <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  placeholder="aziz@ravshanov.uz"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full bg-slate-50 border rounded-xl py-2.5 pl-9 pr-3 text-xs outline-none focus:border-amber-500 ${
                    attempted && !email.trim() ? 'border-red-500 bg-red-50/40 ring-1 ring-red-500' : 'border-slate-300'
                  }`}
                />
              </div>
              {attempted && !email.trim() && (
                <span className="text-[10px] text-red-600 font-bold mt-0.5 block">
                  To'ldirish shart!
                </span>
              )}
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                Parol: <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`w-full bg-slate-50 border rounded-xl py-2.5 pl-9 pr-3 text-xs outline-none focus:border-amber-500 ${
                    attempted && !password ? 'border-red-500 bg-red-50/40 ring-1 ring-red-500' : 'border-slate-300'
                  }`}
                />
              </div>
              {attempted && !password && (
                <span className="text-[10px] text-red-600 font-bold mt-0.5 block">
                  To'ldirish shart!
                </span>
              )}
            </div>

            {tab === 'register' && (
              <>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                    Telefon Raqamingiz (+998): <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder="+998 90 123 45 67"
                      value={phone}
                      onChange={(e) => handlePhoneChange(e.target.value)}
                      className={`w-full bg-slate-50 border rounded-xl py-2.5 pl-9 pr-3 text-xs outline-none focus:border-amber-500 font-semibold ${
                        attempted && (!phone.trim() || phone.trim() === '+998') ? 'border-red-500 bg-red-50/40 ring-1 ring-red-500' : 'border-slate-300'
                      }`}
                    />
                  </div>
                  {attempted && (!phone.trim() || phone.trim() === '+998') && (
                    <span className="text-[10px] text-red-600 font-bold mt-0.5 block">
                      To'ldirish shart!
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                      Shahar:
                    </label>
                    <select
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl py-2.5 px-3 text-xs outline-none"
                    >
                      <option value="Toshkent">Toshkent</option>
                      <option value="Samarqand">Samarqand</option>
                      <option value="Buxoro">Buxoro</option>
                      <option value="Namangan">Namangan</option>
                      <option value="Andijon">Andijon</option>
                      <option value="Farg'ona">Farg'ona</option>
                      <option value="Xiva">Xiva</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                      Manzil: <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="Ko'cha va uy"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className={`w-full bg-slate-50 border rounded-xl py-2.5 px-3 text-xs outline-none focus:border-amber-500 ${
                        attempted && !address.trim() ? 'border-red-500 bg-red-50/40 ring-1 ring-red-500' : 'border-slate-300'
                      }`}
                    />
                    {attempted && !address.trim() && (
                      <span className="text-[10px] text-red-600 font-bold mt-0.5 block">
                        To'ldirish shart!
                      </span>
                    )}
                  </div>
                </div>
              </>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-slate-900 text-white hover:bg-amber-400 hover:text-slate-950 font-black py-3 rounded-xl text-xs uppercase tracking-wider transition-all shadow-md mt-2"
              id="auth-submit-btn"
            >
              {isLoading ? 'Yuklanmoqda...' : tab === 'login' ? 'KIRISH' : "RO'YXATDAN O'TISH"}
            </button>
          </form>

          {/* Quick Demo Hint */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">Admin demo testi:</span>
            <button
              onClick={handleFillAdmin}
              className="text-[11px] text-amber-600 font-bold hover:underline flex items-center space-x-1"
            >
              <ShieldAlert className="w-3 h-3" />
              <span>Admin ma'lumotlarini to'ldirish</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
