import React from 'react';
import { Category } from '../types';

interface CategorySectionProps {
  categories: Category[];
  onSelectCategory: (categoryName: string) => void;
}

export const CategorySection: React.FC<CategorySectionProps> = ({
  categories,
  onSelectCategory
}) => {
  const brands = [
    { name: 'GUCCI', logo: 'GUCCI', font: 'font-serif' },
    { name: 'NIKE', logo: 'NIKE', font: 'font-sans font-black italic tracking-widest' },
    { name: 'ADIDAS', logo: 'adidas', font: 'font-sans font-bold tracking-tight' },
    { name: 'AR RAVSHANOV', logo: 'AR', font: 'font-sans font-black text-amber-500' },
    { name: 'POLO RALPH LAUREN', logo: 'POLO', font: 'font-serif font-bold tracking-widest' }
  ];

  return (
    <div className="space-y-12 py-8 px-4 sm:px-8 max-w-7xl mx-auto">
      {/* Brands Section matching image */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs text-center">
        <div className="flex items-center justify-center space-x-4 mb-6">
          <span className="h-[1px] w-12 bg-slate-300" />
          <h2 className="text-lg font-black text-slate-900 tracking-wider uppercase font-sans">
            TOP BRENDLARIMIZ
          </h2>
          <span className="h-[1px] w-12 bg-slate-300" />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6 items-center justify-center">
          {brands.map((b, idx) => (
            <div
              key={idx}
              onClick={() => onSelectCategory(b.name)}
              className="p-4 bg-slate-50 border border-slate-200 rounded-xl hover:border-amber-400 hover:bg-amber-50/50 cursor-pointer transition-all flex items-center justify-center h-16 group"
            >
              <span className={`text-xl sm:text-2xl text-slate-800 group-hover:scale-105 transition-transform ${b.font}`}>
                {b.logo}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Popular Categories Grid */}
      <div>
        <div className="flex items-center justify-center space-x-4 mb-6">
          <span className="h-[1px] w-12 bg-slate-300" />
          <h2 className="text-lg sm:text-2xl font-black text-slate-900 tracking-wider uppercase font-sans">
            O'MBOB KATEGORIYALAR
          </h2>
          <span className="h-[1px] w-12 bg-slate-300" />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(cat.name)}
              className="group relative h-48 rounded-2xl overflow-hidden cursor-pointer border border-slate-200 shadow-xs hover:shadow-lg transition-all"
            >
              <img
                src={cat.image}
                alt={cat.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <h3 className="font-black text-base sm:text-lg uppercase tracking-wider">{cat.name}</h3>
                <p className="text-[11px] text-amber-400 font-semibold">{cat.productCount || 0} ta mahsulot</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
