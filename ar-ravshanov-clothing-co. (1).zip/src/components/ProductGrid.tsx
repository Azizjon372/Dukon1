import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';

interface ProductGridProps {
  title: string;
  subtitle?: string;
  products: Product[];
  onViewDetails: (product: Product) => void;
  isLoading?: boolean;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  title,
  subtitle,
  products,
  onViewDetails,
  isLoading
}) => {
  return (
    <section className="py-8 px-4 sm:px-8 max-w-7xl mx-auto">
      {/* Section Header matching image layout */}
      <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-200">
        <div>
          <h2 className="text-xl sm:text-2xl font-serif font-bold text-slate-900 tracking-tight">
            {title}
          </h2>
          {subtitle && <p className="text-xs text-slate-400 italic font-serif mt-0.5">{subtitle}</p>}
        </div>

        {/* Carousel Navigation Arrows */}
        <div className="flex items-center space-x-2">
          <button className="w-8 h-8 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-900 hover:text-white flex items-center justify-center transition-colors">
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button className="w-8 h-8 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-900 hover:text-white flex items-center justify-center transition-colors">
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Grid Content */}
      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {[1, 2, 3, 4].map((n) => (
            <div key={n} className="bg-slate-100 rounded-xl aspect-3/4 animate-pulse" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-300">
          <p className="text-sm font-bold text-slate-600">Mahsulotlar topilmadi</p>
          <p className="text-xs text-slate-400 mt-1">Boshqa filter parametrlari bilan urinib ko'ring.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onViewDetails={onViewDetails}
            />
          ))}
        </div>
      )}
    </section>
  );
};
