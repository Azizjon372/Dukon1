import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, ShoppingBag, ShieldCheck, Truck, RefreshCw } from 'lucide-react';

interface HeroProps {
  onShopClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onShopClick }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      title: "BRANDINGIZNI BO'LISHING!",
      subtitle: "ENG SO'NGGI ERKAKLAR VA AYOLLAR KOLLEKSIYALARINI KASHF ETING",
      badge: "YANGI MAVSUM 2026",
      image: "https://images.unsplash.com/photo-1488161628813-04466f872be2?w=1000&q=80",
      cta: "XARID QILING"
    },
    {
      title: "PREMIUM CHARM KURTKALAR",
      subtitle: "100% TABIIY CHARM VA SHVEYTSARIYA DIZAYNI",
      badge: "EKSKLYUZIV KOLLEKSIYA",
      image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=1000&q=80",
      cta: "BATAFSIL KO'RISH"
    },
    {
      title: "LYUKS SOATLAR & AKSESSUARLAR",
      subtitle: "HAR BIKR DETALDA BEJIRIMLIK VA SIFAT",
      badge: "CHEGIRMA -20%",
      image: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=1000&q=80",
      cta: "KATALOGGA O'TISH"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % slides.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);

  const active = slides[currentSlide];

  return (
    <div className="relative bg-[#0f172a] text-white overflow-hidden shadow-xl border-b border-slate-800">
      {/* Gold Diagonal Geometric Accent matching image */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-amber-400/20 via-amber-400/5 to-transparent transform skew-x-12 pointer-events-none" />
      <div className="absolute -bottom-10 -left-10 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 md:py-20 relative z-10 grid grid-cols-1 md:grid-cols-12 gap-8 items-center min-h-[480px]">
        {/* Left Headline Content */}
        <div className="md:col-span-7 space-y-6 text-center md:text-left">
          <div className="inline-flex items-center space-x-2 bg-amber-400/15 border border-amber-400/40 px-3.5 py-1 rounded-full text-amber-400 text-xs font-bold uppercase tracking-widest">
            <span>✨</span>
            <span>{active.badge}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-serif font-black tracking-tight leading-none text-white italic">
            {active.title.split("BO'LISHING")[0]}
            {active.title.includes("BO'LISHING") && (
              <span className="block text-amber-400 mt-1 not-italic font-sans">BO'LISHING!</span>
            )}
          </h1>

          <p className="text-slate-300 text-sm sm:text-base max-w-xl font-medium tracking-wide">
            {active.subtitle}
          </p>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center md:justify-start gap-4">
            <button
              onClick={onShopClick}
              className="w-full sm:w-auto bg-amber-400 text-slate-950 hover:bg-amber-300 font-extrabold px-8 py-4 rounded-xl text-sm tracking-wider uppercase shadow-lg shadow-amber-400/20 flex items-center justify-center space-x-2 transition-all hover:scale-105 active:scale-95"
              id="hero-cta-btn"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>{active.cta}</span>
            </button>
            <div className="text-xs text-slate-400 font-medium flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Barcha mahsulotlar omborda mavjud</span>
            </div>
          </div>
        </div>

        {/* Right Model Showcase Image */}
        <div className="md:col-span-5 relative flex justify-center items-center">
          <div className="relative w-full max-w-md aspect-3/4 rounded-2xl overflow-hidden border-2 border-amber-400/30 shadow-2xl bg-slate-900 group">
            <img
              src={active.image}
              alt={active.title}
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-60" />

            {/* Floating Brand Badge */}
            <div className="absolute bottom-4 left-4 right-4 bg-slate-900/90 backdrop-blur-md p-3.5 rounded-xl border border-amber-400/30 flex items-center justify-between">
              <div>
                <p className="text-[10px] text-amber-400 font-bold uppercase tracking-widest">RAVSHANOV COLLECTION</p>
                <p className="text-xs font-bold text-white uppercase">AR CLOTHING CO.</p>
              </div>
              <span className="text-xs bg-amber-400 text-slate-950 px-2.5 py-1 rounded-md font-black">
                2026
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Carousel Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-slate-900/80 border border-slate-700 text-amber-400 rounded-full flex items-center justify-center hover:bg-amber-400 hover:text-slate-950 transition-all z-20"
        id="hero-prev-slide-btn"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-slate-900/80 border border-slate-700 text-amber-400 rounded-full flex items-center justify-center hover:bg-amber-400 hover:text-slate-950 transition-all z-20"
        id="hero-next-slide-btn"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2 z-20">
        {slides.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            className={`h-2 rounded-full transition-all ${
              currentSlide === idx ? 'w-8 bg-amber-400' : 'w-2 bg-slate-600'
            }`}
          />
        ))}
      </div>

      {/* Bottom Features Strip */}
      <div className="bg-slate-950 border-t border-slate-800/80 py-4 px-4 sm:px-8 text-slate-300 text-xs">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start space-x-2.5">
            <Truck className="w-5 h-5 text-amber-400" />
            <div>
              <p className="font-bold text-white">Tezkor Yetkazish</p>
              <p className="text-[11px] text-slate-400">Toshkent bo'ylab 24 soatda</p>
            </div>
          </div>
          <div className="flex items-center justify-center md:justify-start space-x-2.5">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <div>
              <p className="font-bold text-white">100% Sifat Kafolati</p>
              <p className="text-[11px] text-slate-400">Asl brend mahsulotlari</p>
            </div>
          </div>
          <div className="flex items-center justify-center md:justify-start space-x-2.5">
            <RefreshCw className="w-5 h-5 text-amber-400" />
            <div>
              <p className="font-bold text-white">Oson Almashtirish</p>
              <p className="text-[11px] text-slate-400">14 kun ichida Qaytaring</p>
            </div>
          </div>
          <div className="flex items-center justify-center md:justify-start space-x-2.5">
            <span className="text-xl">💳</span>
            <div>
              <p className="font-bold text-white">Xavfsiz To'lov</p>
              <p className="text-[11px] text-slate-400">Click, Payme, Naqd</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
