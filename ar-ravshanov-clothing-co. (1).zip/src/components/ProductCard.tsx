import React from 'react';
import { Heart, Star, ShoppingBag, Eye } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onViewDetails }) => {
  const { addToCart, toggleWishlist, isInWishlist } = useCart();
  const isWished = isInWishlist(product.id);

  const formatPrice = (price: number) => {
    return price.toLocaleString('uz-UZ') + ' UZS';
  };

  return (
    <div className="group bg-white rounded-3xl p-4 border border-slate-100 shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between">
      {/* Product Image Container */}
      <div className="relative aspect-4/5 bg-slate-100 rounded-2xl overflow-hidden cursor-pointer mb-3" onClick={() => onViewDetails(product)}>
        <img
          src={product.images[0] || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&q=80'}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Wishlist Heart Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product);
          }}
          className={`absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md shadow-xs transition-colors ${
            isWished
              ? 'bg-red-500 text-white'
              : 'bg-white/80 text-slate-700 hover:bg-white hover:text-red-500'
          }`}
          title="Saralanganlarga qo'shish"
          id={`wishlist-btn-${product.id}`}
        >
          <Heart className={`w-4 h-4 ${isWished ? 'fill-current' : ''}`} />
        </button>

        {/* Discount Badge */}
        {product.discount && (
          <div className="absolute top-3 left-3 bg-rose-500 text-white text-[9px] font-bold px-2 py-1 rounded shadow-xs uppercase tracking-wider">
            -{product.discount}% Off
          </div>
        )}

        {/* Quick View Hover Overlay */}
        <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <span className="bg-slate-900/90 text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center space-x-1 backdrop-blur-xs">
            <Eye className="w-3.5 h-3.5" />
            <span>Batafsil</span>
          </span>
        </div>
      </div>

      {/* Product Info Section */}
      <div className="flex flex-col flex-1 justify-between space-y-2">
        <div>
          <h4
            onClick={() => onViewDetails(product)}
            className="text-xs sm:text-sm font-serif font-bold text-slate-900 line-clamp-1 hover:text-amber-600 cursor-pointer"
          >
            {product.name}
          </h4>
          <p className="text-[10px] text-slate-400 mb-1 italic font-serif">
            {product.category} · {product.brand}
          </p>
        </div>

        {/* Price & Rating Row */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-100">
          <div>
            <span className="text-sm font-black text-slate-900">
              {formatPrice(product.price)}
            </span>
            {product.oldPrice && (
              <p className="text-[10px] text-slate-400 line-through">
                {formatPrice(product.oldPrice)}
              </p>
            )}
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              addToCart(product);
            }}
            className="w-8 h-8 rounded-full bg-slate-900 text-white hover:bg-amber-400 hover:text-slate-950 flex items-center justify-center transition-colors shadow-xs"
            title="Savatchaga qo'shish"
            id={`add-to-cart-btn-${product.id}`}
          >
            <ShoppingBag className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
