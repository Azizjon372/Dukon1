import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, Tag, CheckCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { validatePromoCode } from '../services/api';

interface CartDrawerProps {
  onCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ onCheckout }) => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    removeFromCart,
    updateQuantity,
    subtotal,
    deliveryFee,
    discountAmount,
    total,
    appliedPromo,
    applyPromo
  } = useCart();

  const [promoInput, setPromoInput] = useState('');
  const [promoError, setPromoError] = useState('');
  const [isValidating, setIsValidating] = useState(false);

  if (!isCartOpen) return null;

  const formatPrice = (price: number) => price.toLocaleString('uz-UZ') + ' UZS';

  const handleApplyPromo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoInput.trim()) return;
    setIsValidating(true);
    setPromoError('');
    try {
      const res = await validatePromoCode(promoInput.trim(), subtotal);
      applyPromo(res);
      setPromoInput('');
    } catch (err: any) {
      setPromoError(err.message || 'Promokod xatosi');
    } finally {
      setIsValidating(false);
    }
  };

  const freeShippingThreshold = 500000;
  const freeShippingProgress = Math.min(100, (subtotal / freeShippingThreshold) * 100);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div
        className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between">
          {/* Drawer Header */}
          <div className="p-4 sm:p-6 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <ShoppingBag className="w-5 h-5 text-amber-400" />
              <h2 className="font-extrabold text-base tracking-wider uppercase font-sans">
                SAVATCHANINGIZ ({cart.length})
              </h2>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              id="close-cart-drawer-btn"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Free Shipping Bar */}
          <div className="bg-slate-50 px-4 py-3 border-b border-slate-200">
            <div className="flex justify-between text-xs font-semibold mb-1">
              {subtotal >= freeShippingThreshold ? (
                <span className="text-emerald-700 font-bold flex items-center space-x-1">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Siz uchun yetkazib berish BEPUL!</span>
                </span>
              ) : (
                <span className="text-slate-600">
                  Bepul yetkazish uchun yana{' '}
                  <strong className="text-slate-900">
                    {formatPrice(freeShippingThreshold - subtotal)}
                  </strong>{' '}
                  xarid qiling
                </span>
              )}
            </div>
            <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-400 transition-all duration-500"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            {cart.length === 0 ? (
              <div className="text-center py-16 space-y-3">
                <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <p className="font-bold text-slate-700 text-sm">Savatchangiz bo'sh</p>
                <p className="text-xs text-slate-400">
                  Katalogimizdan o'zingizga yoqqan kiyimlarni tanlang.
                </p>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={item.id}
                  className="flex space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-200 relative group"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-20 object-cover rounded-lg border border-slate-200 bg-white"
                  />
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 text-xs uppercase line-clamp-1">
                        {item.name}
                      </h4>
                      <p className="text-[10px] text-slate-500">
                        O'lcham: <strong className="text-slate-800">{item.selectedSize}</strong> | Rang:{' '}
                        <strong className="text-slate-800">{item.selectedColor}</strong>
                      </p>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      <span className="font-black text-slate-900 text-xs">
                        {formatPrice(item.price)}
                      </span>

                      <div className="flex items-center border border-slate-300 rounded bg-white">
                        <button
                          onClick={() => updateQuantity(item.id, -1)}
                          className="px-2 py-0.5 text-xs font-bold text-slate-600 hover:bg-slate-100"
                        >
                          -
                        </button>
                        <span className="px-2 text-xs font-bold">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, 1)}
                          className="px-2 py-0.5 text-xs font-bold text-slate-600 hover:bg-slate-100"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="p-1 text-slate-400 hover:text-red-500"
                    title="O'chirish"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Drawer Footer & Checkout */}
          {cart.length > 0 && (
            <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-200 space-y-4">
              {/* Promo Code Input */}
              <div>
                {appliedPromo ? (
                  <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-xs">
                    <span className="font-bold text-emerald-800 flex items-center space-x-1">
                      <Tag className="w-3.5 h-3.5" />
                      <span>{appliedPromo.code} promokodi qo'llanildi</span>
                    </span>
                    <button
                      onClick={() => applyPromo(null)}
                      className="text-red-600 font-bold hover:underline"
                    >
                      Bekor qilish
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyPromo} className="flex space-x-2">
                    <input
                      type="text"
                      placeholder="Promokod (masalan: RAVSHANOV10)"
                      value={promoInput}
                      onChange={(e) => setPromoInput(e.target.value)}
                      className="flex-1 bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs outline-none focus:border-amber-500 uppercase font-semibold"
                    />
                    <button
                      type="submit"
                      disabled={isValidating}
                      className="bg-slate-900 text-white font-bold px-3 py-2 rounded-lg text-xs uppercase hover:bg-amber-400 hover:text-slate-950 transition-colors"
                    >
                      Qo'llash
                    </button>
                  </form>
                )}
                {promoError && <p className="text-[11px] text-red-600 mt-1 font-semibold">{promoError}</p>}
              </div>

              {/* Price Calculation Summary */}
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Mahsulotlar summasi:</span>
                  <span className="font-semibold text-slate-900">{formatPrice(subtotal)}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-bold">
                    <span>Chegirma:</span>
                    <span>-{formatPrice(discountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>Yetkazib berish:</span>
                  <span className="font-semibold text-slate-900">
                    {deliveryFee === 0 ? 'BEPUL' : formatPrice(deliveryFee)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-900 font-black text-base pt-2 border-t border-slate-200">
                  <span>JAMI TO'LOV:</span>
                  <span className="text-amber-600">{formatPrice(total)}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={() => {
                  setIsCartOpen(false);
                  onCheckout();
                }}
                className="w-full bg-amber-400 text-slate-950 hover:bg-amber-300 font-black py-3.5 rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-amber-400/20 flex items-center justify-center space-x-2 transition-all active:scale-98"
                id="proceed-to-checkout-btn"
              >
                <span>XARIDNI RASMIYLASHTIRISH</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
