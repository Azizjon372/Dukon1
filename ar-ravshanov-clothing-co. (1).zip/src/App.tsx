import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider, useCart } from './context/CartContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { AuthModal } from './components/AuthModal';
import { ProductDetailsModal } from './components/ProductDetailsModal';

import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { AccountPage } from './pages/AccountPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';

import { AdminLayout } from './admin/AdminLayout';
import { AdminLogin } from './admin/AdminLogin';

import { Product, Category, Order } from './types';
import { fetchProducts, fetchCategories } from './services/api';

const MainAppContent: React.FC = () => {
  const { user } = useAuth();
  const { cart } = useCart();

  // Navigation State
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('barchasi');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals & Drawers
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Core Data
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [dataLoading, setDataLoading] = useState(true);

  // Initial Data Load
  const loadInitialData = async () => {
    setDataLoading(true);
    try {
      const [pRes, cRes] = await Promise.all([
        fetchProducts({ limit: 20 }),
        fetchCategories()
      ]);
      setProducts(pRes.products);
      setCategories(cRes);
    } catch (err) {
      console.error('Initial data fetch error:', err);
    } finally {
      setDataLoading(false);
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  // Handle direct tab routing
  const handleSelectCategory = (catName: string) => {
    setSelectedCategoryFilter(catName);
    setCurrentTab('products');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearchSubmit = (query: string) => {
    setSearchQuery(query);
    setCurrentTab('products');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Dedicated Route Handler for Admin Panel
  if (currentTab === 'admin') {
    if (user && user.role === 'admin') {
      return <AdminLayout onBackToStore={() => setCurrentTab('home')} />;
    }
    return <AdminLogin onSuccess={() => setCurrentTab('admin')} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans text-slate-800 antialiased selection:bg-amber-400 selection:text-slate-950">
      {/* Top Main Navbar */}
      <Navbar
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          setCurrentTab(tab);
          if (tab === 'clothing') {
            setSelectedCategoryFilter('Kiyimlar');
            setCurrentTab('products');
          } else if (tab === 'accessories') {
            setSelectedCategoryFilter('Aksessuarlar');
            setCurrentTab('products');
          } else if (tab === 'new-arrivals') {
            setSelectedCategoryFilter('barchasi');
            setCurrentTab('products');
          } else if (tab === 'sale') {
            setSelectedCategoryFilter('barchasi');
            setCurrentTab('products');
          }
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSearch={handleSearchSubmit}
      />

      {/* Main Page View Switcher */}
      <main className="flex-1">
        {currentTab === 'home' && (
          <HomePage
            products={products}
            categories={categories}
            onViewDetails={(p) => setSelectedProduct(p)}
            onSelectCategory={handleSelectCategory}
            setCurrentTab={setCurrentTab}
            isLoading={dataLoading}
          />
        )}

        {currentTab === 'products' && (
          <ProductsPage
            categories={categories}
            initialCategory={selectedCategoryFilter}
            initialSearch={searchQuery}
            onViewDetails={(p) => setSelectedProduct(p)}
          />
        )}

        {currentTab === 'checkout' && (
          <CheckoutPage
            onBackToShop={() => setCurrentTab('products')}
            onOrderSuccess={(ord) => {
              // Stay on confirmation screen or allow user to navigate
            }}
          />
        )}

        {currentTab === 'account' && <AccountPage />}
        {currentTab === 'about' && <AboutPage />}
        {currentTab === 'contact' && <ContactPage />}
      </main>

      {/* Footer Component */}
      <Footer setCurrentTab={setCurrentTab} />

      {/* Slide-over Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onCheckout={() => {
          setIsCartOpen(false);
          setCurrentTab('checkout');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      {/* Product Details Modal */}
      <ProductDetailsModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />
    </div>
  );
};

export function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <MainAppContent />
      </CartProvider>
    </AuthProvider>
  );
}

export default App;
